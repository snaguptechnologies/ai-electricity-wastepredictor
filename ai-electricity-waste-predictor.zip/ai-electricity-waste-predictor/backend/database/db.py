"""SQLite access, schema and validated settings."""
import json, math, os, re, sqlite3
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from flask import current_app, g

SCHEMA = """
CREATE TABLE IF NOT EXISTS readings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp TEXT NOT NULL,
  device_id TEXT NOT NULL,
  voltage REAL CHECK(voltage IS NULL OR (voltage>=0 AND voltage<=500)),
  "current" REAL CHECK("current" IS NULL OR ("current">=0 AND "current"<=100)),
  power REAL CHECK(power IS NULL OR power>=0),
  energy_kwh REAL CHECK(energy_kwh IS NULL OR energy_kwh>=0),
  data_source TEXT NOT NULL CHECK(data_source IN ('live_iot','thingspeak_history','manual','sample')),
  expected_power REAL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
  UNIQUE(device_id, timestamp)
);
CREATE INDEX IF NOT EXISTS idx_readings_ts ON readings(timestamp);
CREATE INDEX IF NOT EXISTS idx_readings_src ON readings(data_source, timestamp);

CREATE TABLE IF NOT EXISTS predictions(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  prediction_timestamp TEXT NOT NULL,
  target_timestamp TEXT NOT NULL,
  predicted_energy_kwh REAL NOT NULL CHECK(predicted_energy_kwh>=0),
  model_name TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);
CREATE INDEX IF NOT EXISTS idx_pred_target ON predictions(target_timestamp);

CREATE TABLE IF NOT EXISTS alerts(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp TEXT NOT NULL,
  alert_type TEXT NOT NULL CHECK(alert_type IN ('voltage_anomaly','high_power','excess_energy','connection_failure')),
  severity TEXT NOT NULL CHECK(severity IN ('Low','Medium','High')),
  measured_value REAL,
  expected_value REAL,
  description TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'open' CHECK(status IN ('open','reviewed','confirmed_waste','resolved')),
  data_source TEXT NOT NULL DEFAULT 'iot',
  created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now')),
  UNIQUE(alert_type, timestamp, data_source)
);
CREATE INDEX IF NOT EXISTS idx_alerts_ts ON alerts(timestamp);

CREATE TABLE IF NOT EXISTS settings(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  setting_key TEXT NOT NULL UNIQUE,
  setting_value TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ','now'))
);
"""

# key: (kind, default, min, max)
SPECS = {
    "device_id": ("device", "ESP32-01", None, None),
    "voltage_baseline": ("float", 230.0, 0, 500),          # 0 = learn from first N readings
    "baseline_readings": ("int", 30, 5, 1000),
    "voltage_threshold_pct": ("float", 4.0, 0.1, 50),
    "consecutive_readings": ("int", 3, 1, 20),
    "high_power_w": ("float", 2000.0, 1, 50000),
    "excess_zscore": ("float", 3.0, 1, 10),
    "excess_min_ratio": ("float", 1.3, 1, 10),
    "tariff_per_unit": ("float", 8.0, 0, 1000),
    "additional_charges": ("float", 0.0, 0, 1e6),
    "power_factor": ("float", 0.9, 0.1, 1),
    "update_interval_s": ("int", 20, 1, 3600),
    "stale_after_s": ("int", 300, 10, 86400),
    "timezone": ("tz", "Asia/Kolkata", None, None),
    "min_train_hours": ("int", 168, 48, 100000),
    "test_fraction": ("float", 0.2, 0.05, 0.5),
    "saving_assumption_pct": ("float", 20.0, 0, 100),
    "telegram_notifications": ("bool", False, None, None),
    "ts_field_voltage": ("field", os.getenv("THINGSPEAK_FIELD_VOLTAGE", "field1"), None, None),
    "ts_field_current": ("field", os.getenv("THINGSPEAK_FIELD_CURRENT", "field2"), None, None),
    "ts_field_power": ("field", os.getenv("THINGSPEAK_FIELD_POWER", "field3"), None, None),
    "ts_field_energy": ("field", os.getenv("THINGSPEAK_FIELD_ENERGY", "field4"), None, None),
    "ts_energy_unit": ("unit", "kWh", None, None),
}


def utcnow_iso():
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def connect(path):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    conn = sqlite3.connect(path, timeout=10)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys=ON")
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def get_db():
    if "db" not in g:
        g.db = connect(current_app.config["DB_PATH"])
    return g.db


def close_db(_=None):
    conn = g.pop("db", None)
    if conn is not None:
        conn.close()


def init_db(path):
    conn = connect(path)
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


def coerce(key, val):
    """Validate one setting. Raises KeyError for unknown keys, ValueError for bad values."""
    kind, _, lo, hi = SPECS[key]
    if kind == "bool":
        if isinstance(val, bool):
            return val
        raise ValueError("must be true or false")
    if kind in ("int", "float"):
        if isinstance(val, bool) or val is None or val == "":
            raise ValueError("must be a number")
        try:
            x = float(val)
        except (TypeError, ValueError):
            raise ValueError("must be a number")
        if not math.isfinite(x) or x < lo or x > hi:
            raise ValueError(f"must be between {lo} and {hi}")
        if kind == "int":
            if x != int(x):
                raise ValueError("must be a whole number")
            return int(x)
        return x
    s = str(val).strip()
    if kind == "device":
        if not re.fullmatch(r"[A-Za-z0-9_.-]{1,64}", s):
            raise ValueError("use 1-64 letters, digits, dot, dash or underscore")
        return s
    if kind == "tz":
        try:
            ZoneInfo(s)
        except Exception:
            raise ValueError("must be a valid IANA timezone, e.g. Asia/Kolkata")
        return s
    if kind == "field":
        s = s.lower()
        if not re.fullmatch(r"field[1-8]", s):
            raise ValueError("must be field1 ... field8")
        return s
    if kind == "unit":
        if s not in ("kWh", "Wh"):
            raise ValueError("must be kWh or Wh")
        return s
    raise ValueError("invalid")


def get_settings(conn):
    out = {k: v[1] for k, v in SPECS.items()}
    for row in conn.execute("SELECT setting_key, setting_value FROM settings"):
        if row["setting_key"] in SPECS:
            try:
                out[row["setting_key"]] = coerce(row["setting_key"], json.loads(row["setting_value"]))
            except (ValueError, KeyError, json.JSONDecodeError):
                pass
    return out


def _upsert(conn, key, value):
    conn.execute(
        "INSERT INTO settings(setting_key,setting_value,updated_at) VALUES(?,?,?) "
        "ON CONFLICT(setting_key) DO UPDATE SET setting_value=excluded.setting_value, updated_at=excluded.updated_at",
        (key, json.dumps(value), utcnow_iso()))


def save_settings(conn, values):
    for k, v in values.items():
        _upsert(conn, k, v)
    conn.commit()


def get_state(conn, key, default=None):
    """Internal runtime state (not user-editable); keys start with '_'."""
    row = conn.execute("SELECT setting_value FROM settings WHERE setting_key=?", ("_" + key,)).fetchone()
    return json.loads(row["setting_value"]) if row else default


def set_state(conn, key, value):
    _upsert(conn, "_" + key, value)
    conn.commit()


def insert_reading(conn, r):
    cur = conn.execute(
        'INSERT OR IGNORE INTO readings(timestamp,device_id,voltage,"current",power,energy_kwh,data_source,expected_power) '
        "VALUES(?,?,?,?,?,?,?,?)",
        (r["timestamp"], r["device_id"], r.get("voltage"), r.get("current"), r.get("power"),
         r.get("energy_kwh"), r["data_source"], r.get("expected_power")))
    return cur.rowcount == 1

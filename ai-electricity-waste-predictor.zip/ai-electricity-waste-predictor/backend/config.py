"""Application configuration. Secrets come ONLY from environment variables / backend/.env."""
import os
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / "backend" / ".env")


def build_config():
    return {
        "ROOT": str(ROOT),
        "DB_PATH": os.getenv("DATABASE_PATH") or str(ROOT / "data" / "electricity.db"),
        "FRONTEND_DIR": str(ROOT / "frontend"),
        "MODEL_DIR": str(ROOT / "data" / "models"),
        "SAMPLE_CSV": str(ROOT / "data" / "sample_readings.csv"),
        "TS_CHANNEL_ID": os.getenv("THINGSPEAK_CHANNEL_ID", "").strip(),
        "TS_READ_KEY": os.getenv("THINGSPEAK_READ_API_KEY", "").strip(),
        "TS_WRITE_KEY": os.getenv("THINGSPEAK_WRITE_API_KEY", "").strip(),
        "TS_BASE": os.getenv("THINGSPEAK_API_BASE_URL", "https://api.thingspeak.com").rstrip("/"),
        "AUTO_SYNC_SECONDS": int(os.getenv("AUTO_SYNC_SECONDS", "0") or 0),
        "DEVICE_API_KEY": os.getenv("DEVICE_API_KEY", "").strip(),
        "TELEGRAM_BOT_TOKEN": os.getenv("TELEGRAM_BOT_TOKEN", "").strip(),
        "TELEGRAM_CHAT_ID": os.getenv("TELEGRAM_CHAT_ID", "").strip(),
        "FRONTEND_ORIGIN": os.getenv("FRONTEND_ORIGIN", "http://localhost:5000").strip(),
        "MAX_CONTENT_LENGTH": 5 * 1024 * 1024,
    }

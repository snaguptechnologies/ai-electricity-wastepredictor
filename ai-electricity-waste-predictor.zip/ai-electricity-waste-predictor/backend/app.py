"""AI Electricity Waste Predictor: Flask entry point.  Run:  python backend/app.py"""
import logging, os, sys, threading, time
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from flask import Flask, jsonify, request, send_from_directory
from flask_cors import CORS
from config import build_config
from database import db
from services import detection, sample_data, thingspeak


def _auto_sync(cfg):
    while True:
        time.sleep(cfg["AUTO_SYNC_SECONDS"])
        try:
            conn = db.connect(cfg["DB_PATH"])
            try:
                thingspeak.run_sync(conn, cfg, db.get_settings(conn))
            finally:
                conn.close()
        except Exception as e:       # keep the poller alive
            logging.warning("auto-sync failed: %s", e)


def create_app(overrides=None):
    cfg = build_config()
    cfg.update(overrides or {})
    app = Flask(__name__, static_folder=cfg["FRONTEND_DIR"], static_url_path="")
    app.config.update(cfg)
    db.init_db(cfg["DB_PATH"])
    conn = db.connect(cfg["DB_PATH"])
    st = db.get_settings(conn)
    if sample_data.seed(conn, st, cfg):
        detection.refresh_alerts(conn, cfg, st, rebuild=True)
    conn.close()
    app.teardown_appcontext(db.close_db)
    CORS(app, resources={r"/api/*": {"origins": [cfg["FRONTEND_ORIGIN"]]}})
    from routes.api import bp
    app.register_blueprint(bp)

    @app.get("/")
    def index():
        return send_from_directory(app.static_folder, "index.html")

    def _json_err(code, msg):
        if request.path.startswith("/api"):
            return jsonify({"error": msg}), code
        return msg, code

    app.register_error_handler(404, lambda e: _json_err(404, "Not found"))
    app.register_error_handler(405, lambda e: _json_err(405, "Method not allowed"))
    app.register_error_handler(413, lambda e: _json_err(413, "Upload too large (max 5 MB)"))
    app.register_error_handler(500, lambda e: _json_err(500, "Internal server error"))

    if cfg["AUTO_SYNC_SECONDS"] > 0 and thingspeak.configured(cfg) and not cfg.get("TESTING"):
        threading.Thread(target=_auto_sync, args=(cfg,), daemon=True).start()
    return app


if __name__ == "__main__":
    create_app().run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=os.getenv("FLASK_DEBUG") == "1")

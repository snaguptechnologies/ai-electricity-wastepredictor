"""REST API. All responses are JSON; no secrets are ever returned."""
import csv, hmac, io, math
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
import pandas as pd
from flask import Blueprint, Response, current_app, jsonify, request
from database import db
from ml import forecast
from services import analysis as A, detection, notify, sample_data, thingspeak as ts

bp = Blueprint("api", __name__, url_prefix="/api")


class ApiError(Exception):
    def __init__(self, msg, code=400, details=None):
        self.msg, self.code, self.details = msg, code, details


@bp.errorhandler(ApiError)
def _err(e):
    body = {"error": e.msg}
    if e.details:
        body["details"] = e.details
    return jsonify(body), e.code


def ok(data, code=200):
    return jsonify(A.jsonable(data)), code


def ctx():
    conn = db.get_db()
    return conn, current_app.config, db.get_settings(conn)


def body_json():
    d = request.get_json(silent=True)
    if not isinstance(d, dict):
        raise ApiError("Request body must be a JSON object", 400)
    return d


def day_bound(s, st, end=False):
    try:
        d = datetime.fromisoformat(s.strip().replace("Z", "+00:00"))
    except ValueError:
        raise ApiError(f"Invalid date '{s}'. Use YYYY-MM-DD", 400)
    if d.tzinfo is None:
        d = d.replace(tzinfo=ZoneInfo(st["timezone"]))
        if len(s.strip()) <= 10 and end:
            d += timedelta(days=1) - timedelta(seconds=1)
    return d.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


# ---------------------------------------------------------------- health
@bp.get("/health")
def health():
    conn, cfg, st = ctx()
    conn.execute("SELECT 1")
    return ok({"status": "ok", "time": db.utcnow_iso(), "database": "ok", "version": "1.0.0",
               "thingspeak": ts.status(conn, cfg, st)})


# ---------------------------------------------------------------- dashboard etc.
@bp.get("/dashboard")
def dashboard():
    conn, cfg, st = ctx()
    return ok(A.build_dashboard(conn, cfg, st, ts.status(conn, cfg, st)))


@bp.get("/waste")
def waste():
    conn, cfg, st = ctx()
    return ok(A.build_waste(conn, st))


@bp.get("/recommendations")
def recs():
    conn, cfg, st = ctx()
    df, mode = A.load_df(conn, st)
    h = A.hourly_series(df, st["timezone"])
    return ok({"mode": mode, "recommendations": A.recommendations(df, h, st, conn, A.alert_source(mode)),
               "note": "Savings are estimates based on the stated assumptions, not guaranteed."})


# ---------------------------------------------------------------- readings
def _num(d, k, lo, hi, errs, required=False):
    v = d.get(k)
    if v is None or v == "":
        if required:
            errs[k] = "required"
        return None
    if isinstance(v, bool):
        errs[k] = "must be a number"
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        errs[k] = "must be a number"
        return None
    if not math.isfinite(x) or x < lo or x > hi:
        errs[k] = f"must be between {lo} and {hi}"
        return None
    return x


def validate_reading(d, st):
    errs = {}
    v = _num(d, "voltage", 0, 500, errs, True)
    i = _num(d, "current", 0, 100, errs, True)
    p = _num(d, "power", 0, 50000, errs)
    e = _num(d, "energy_kwh", 0, 1e7, errs)
    dev = str(d.get("device_id") or st["device_id"]).strip()
    if not dev or len(dev) > 64 or any(c in dev for c in " <>\"'"):
        errs["device_id"] = "1-64 characters, no spaces or quotes"
    t = d.get("timestamp")
    stamp = None
    if t in (None, ""):
        stamp = db.utcnow_iso()
    else:
        try:
            x = datetime.fromisoformat(str(t).strip().replace("Z", "+00:00"))
            if x.tzinfo is None:
                x = x.replace(tzinfo=ZoneInfo(st["timezone"]))
            x = x.astimezone(timezone.utc)
            if x > datetime.now(timezone.utc) + timedelta(minutes=5):
                errs["timestamp"] = "must not be in the future"
            stamp = x.strftime("%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            errs["timestamp"] = "must be ISO 8601, e.g. 2025-01-31T14:30"
    if errs:
        return None, errs
    if p is None:
        p = round(v * i * st["power_factor"], 2)   # estimate (power factor from settings)
    return {"timestamp": stamp, "device_id": dev, "voltage": v, "current": i, "power": p, "energy_kwh": e}, None


@bp.get("/readings")
def readings():
    conn, cfg, st = ctx()
    df, _ = A.load_df(conn, st)
    expr, ep = A.status_sql(A.get_baseline(df, st), st)
    where, wp = [], []
    a = request.args
    if a.get("from"): where.append("timestamp>=?"); wp.append(day_bound(a["from"], st))
    if a.get("to"): where.append("timestamp<=?"); wp.append(day_bound(a["to"], st, True))
    if a.get("source"):
        if a["source"] not in ("live_iot", "thingspeak_history", "manual", "sample"):
            raise ApiError("Unknown source", 400)
        where.append("data_source=?"); wp.append(a["source"])
    if a.get("status"):
        where.append("status=?"); wp.append(a["status"])
    if a.get("q"):
        like = f"%{a['q'].strip()[:50]}%"
        where.append("(device_id LIKE ? OR timestamp LIKE ? OR data_source LIKE ? OR CAST(voltage AS TEXT) LIKE ? OR CAST(power AS TEXT) LIKE ?)")
        wp += [like] * 5
    sort = a.get("sort", "timestamp")
    if sort not in ("timestamp", "voltage", "current", "power", "energy_kwh", "device_id", "data_source", "status"):
        raise ApiError("Invalid sort column", 400)
    order = "ASC" if a.get("order", "desc").lower() == "asc" else "DESC"
    try:
        page, per = max(int(a.get("page", 1)), 1), min(max(int(a.get("per_page", 25)), 1), 200)
    except ValueError:
        raise ApiError("page and per_page must be integers", 400)
    sub = (f'(SELECT id,timestamp,device_id,voltage,"current" AS current,power,energy_kwh,data_source,expected_power,{expr} AS status FROM readings)')
    w = (" WHERE " + " AND ".join(where)) if where else ""
    total = conn.execute(f"SELECT COUNT(*) FROM {sub}{w}", ep + wp).fetchone()[0]
    rows = conn.execute(f"SELECT * FROM {sub}{w} ORDER BY {sort} {order}, id DESC LIMIT ? OFFSET ?", ep + wp + [per, (page - 1) * per]).fetchall()
    return ok({"readings": [dict(r) for r in rows], "total": total, "page": page, "per_page": per,
               "pages": max(math.ceil(total / per), 1)})


@bp.post("/readings")
def add_reading():
    conn, cfg, st = ctx()
    d = body_json()
    source, key = "manual", request.headers.get("X-API-Key")
    if key is not None:
        if not cfg["DEVICE_API_KEY"] or not hmac.compare_digest(key, cfg["DEVICE_API_KEY"]):
            raise ApiError("Invalid or missing device API key", 401)
        source = "live_iot"
    clean, errs = validate_reading(d, st)
    if errs:
        raise ApiError("Validation failed", 422, errs)
    clean["data_source"] = source
    if not db.insert_reading(conn, clean):
        raise ApiError("A reading for this device and timestamp already exists", 409)
    conn.commit()
    detection.refresh_alerts(conn, cfg, st)
    return ok({"reading": clean}, 201)


@bp.post("/readings/import")
def import_csv():
    conn, cfg, st = ctx()
    f = request.files.get("file")
    if not f:
        raise ApiError("Upload a CSV file in the 'file' field", 400)
    try:
        rows = list(csv.DictReader(io.StringIO(f.read().decode("utf-8-sig"))))
    except (UnicodeDecodeError, csv.Error):
        raise ApiError("File must be a UTF-8 CSV", 400)
    if not rows:
        raise ApiError("CSV has no data rows", 400)
    if len(rows) > 20000:
        raise ApiError("Too many rows (max 20,000)", 413)
    need = {"timestamp", "voltage", "current"}
    if not need <= set(rows[0].keys()):
        raise ApiError(f"CSV must have columns: {', '.join(sorted(need))} (optional: device_id, power, energy_kwh)", 400)
    ins = dup = 0
    errors = []
    for n, r in enumerate(rows, start=2):
        clean, errs = validate_reading({k: (v.strip() if isinstance(v, str) else v) for k, v in r.items()}, st)
        if errs:
            if len(errors) < 20:
                errors.append({"line": n, "errors": errs})
            continue
        clean["data_source"] = "manual"
        if db.insert_reading(conn, clean): ins += 1
        else: dup += 1
    conn.commit()
    detection.refresh_alerts(conn, cfg, st)
    return ok({"inserted": ins, "duplicates": dup, "rejected": len(rows) - ins - dup, "errors": errors})


@bp.get("/readings/export")
def export_csv():
    conn, cfg, st = ctx()
    where, p = [], []
    if request.args.get("from"): where.append("timestamp>=?"); p.append(day_bound(request.args["from"], st))
    if request.args.get("to"): where.append("timestamp<=?"); p.append(day_bound(request.args["to"], st, True))
    if request.args.get("source"): where.append("data_source=?"); p.append(request.args["source"])
    w = (" WHERE " + " AND ".join(where)) if where else ""
    rows = conn.execute(f'SELECT timestamp,device_id,voltage,"current" AS current,power,energy_kwh,data_source FROM readings{w} ORDER BY timestamp LIMIT 100000', p)
    out = io.StringIO()
    wr = csv.writer(out)
    wr.writerow(["timestamp", "device_id", "voltage", "current", "power", "energy_kwh", "data_source"])
    for r in rows:
        wr.writerow(list(r))
    return Response(out.getvalue(), mimetype="text/csv", headers={"Content-Disposition": "attachment; filename=readings.csv"})


# ---------------------------------------------------------------- predictions
@bp.get("/predictions")
def predictions():
    conn, cfg, st = ctx()
    df, mode = A.load_df(conn, st)
    res = forecast.run(A.hourly_series(df, st["timezone"]), st, cfg["MODEL_DIR"])
    res["mode"] = mode
    return ok(res)


@bp.post("/predict")
def predict():
    conn, cfg, st = ctx()
    d = request.get_json(silent=True) or {}
    h = d.get("horizon_hours", 24)
    if isinstance(h, bool) or not isinstance(h, int) or not 1 <= h <= 168:
        raise ApiError("horizon_hours must be an integer from 1 to 168", 422)
    df, mode = A.load_df(conn, st)
    res = forecast.run(A.hourly_series(df, st["timezone"]), st, cfg["MODEL_DIR"], force=bool(d.get("retrain", True)))
    res["mode"] = mode
    res["forecast"] = res["forecast"][:h]
    if res["forecast"]:
        now = db.utcnow_iso()
        name = res["model"]["name"]
        conn.executemany("INSERT INTO predictions(prediction_timestamp,target_timestamp,predicted_energy_kwh,model_name) VALUES(?,?,?,?)",
                         [(now, f["timestamp"], max(f["kwh"], 0), name) for f in res["forecast"]])
        conn.commit()
    return ok(res)


# ---------------------------------------------------------------- alerts
@bp.get("/alerts")
def alerts():
    conn, cfg, st = ctx()
    _, mode = A.load_df(conn, st, limit=1)
    where, p = ["data_source=?"], [A.alert_source(mode)]
    a = request.args
    for col, key, allowed in (("severity", "severity", ("Low", "Medium", "High")),
                              ("status", "status", ("open", "reviewed", "confirmed_waste", "resolved")),
                              ("alert_type", "type", tuple(detection.LABELS))):
        if a.get(key):
            if a[key] not in allowed:
                raise ApiError(f"Invalid {key}", 400)
            where.append(f"{col}=?"); p.append(a[key])
    if a.get("from"): where.append("timestamp>=?"); p.append(day_bound(a["from"], st))
    if a.get("to"): where.append("timestamp<=?"); p.append(day_bound(a["to"], st, True))
    w = " AND ".join(where)
    rows = conn.execute(f"SELECT * FROM alerts WHERE {w} ORDER BY timestamp DESC LIMIT 500", p).fetchall()
    counts = {r["status"]: r["n"] for r in conn.execute("SELECT status, COUNT(*) n FROM alerts WHERE data_source=? GROUP BY status", (A.alert_source(mode),))}
    return ok({"alerts": [detection.decorate(r) for r in rows], "counts": counts, "mode": mode})


@bp.patch("/alerts/<int:alert_id>")
def patch_alert(alert_id):
    conn, cfg, st = ctx()
    d = body_json()
    if d.get("status") not in ("open", "reviewed", "confirmed_waste", "resolved"):
        raise ApiError("status must be one of: open, reviewed, confirmed_waste, resolved", 422)
    cur = conn.execute("UPDATE alerts SET status=? WHERE id=?", (d["status"], alert_id))
    conn.commit()
    if not cur.rowcount:
        raise ApiError("Alert not found", 404)
    return ok({"alert": detection.decorate(conn.execute("SELECT * FROM alerts WHERE id=?", (alert_id,)).fetchone())})


# ---------------------------------------------------------------- settings
def settings_payload(conn, cfg, st):
    df_n = conn.execute("SELECT COUNT(*) FROM readings WHERE data_source='sample'").fetchone()[0]
    _, mode = A.load_df(conn, st, limit=1)
    return {"values": st, "mode": mode, "sample_rows": df_n,
            "integration": {"thingspeak_configured": ts.configured(cfg), "channel_id_set": bool(cfg["TS_CHANNEL_ID"]),
                            "read_key_set": bool(cfg["TS_READ_KEY"]), "write_key_set": bool(cfg["TS_WRITE_KEY"]),
                            "device_api_key_set": bool(cfg["DEVICE_API_KEY"]),
                            "telegram_configured": notify.configured(cfg), "status": ts.status(conn, cfg, st),
                            "auto_sync_seconds": cfg["AUTO_SYNC_SECONDS"]}}


@bp.get("/settings")
def get_settings():
    conn, cfg, st = ctx()
    return ok(settings_payload(conn, cfg, st))


@bp.put("/settings")
def put_settings():
    conn, cfg, st = ctx()
    d = body_json()
    clean, errs = {}, {}
    for k, v in d.items():
        if k not in db.SPECS:
            errs[k] = "unknown setting"
            continue
        try:
            clean[k] = db.coerce(k, v)
        except ValueError as e:
            errs[k] = str(e)
    if errs:
        raise ApiError("Validation failed", 422, errs)
    db.save_settings(conn, clean)
    st = db.get_settings(conn)
    detection.refresh_alerts(conn, cfg, st, rebuild=True)
    return ok(settings_payload(conn, cfg, st))


@bp.post("/sample/reset")
def reset_sample():
    conn, cfg, st = ctx()
    sample_data.seed(conn, st, cfg, reset=True)
    detection.refresh_alerts(conn, cfg, st, rebuild=True)
    return ok({"message": "Sample data regenerated", "rows": conn.execute("SELECT COUNT(*) FROM readings WHERE data_source='sample'").fetchone()[0]})


# ---------------------------------------------------------------- thingspeak
@bp.post("/thingspeak/sync")
def thingspeak_sync():
    conn, cfg, st = ctx()
    if not ts.configured(cfg):
        raise ApiError("ThingSpeak is not configured. Set THINGSPEAK_CHANNEL_ID in backend/.env (demo mode is active).", 503)
    try:
        return ok(ts.run_sync(conn, cfg, st))
    except ts.TSError as e:
        raise ApiError(str(e), 502)

"""Alert detection. Alerts are prompts to investigate, NOT proof of electricity waste."""
import numpy as np, pandas as pd
from database import db
from services import analysis as A, notify

LABELS = {"voltage_anomaly": "Voltage anomaly", "high_power": "Unusually high power",
          "excess_energy": "Excess energy consumption", "connection_failure": "Connection failure"}
UNITS = {"voltage_anomaly": "V", "high_power": "W", "excess_energy": "kWh", "connection_failure": ""}
CAUSES = {
    "voltage_anomaly": ["Supply fluctuation or heavy nearby load", "Loose connection or wiring fault",
                        "Voltage sensor not calibrated, or noisy ADC readings"],
    "high_power": ["Several large appliances running together", "Appliance fault or stuck-on equipment",
                   "Current sensor offset / calibration error"],
    "excess_energy": ["Equipment left on unintentionally", "Change in occupancy or routine", "Appliance running inefficiently"],
    "connection_failure": ["Wi-Fi or ESP32 offline", "Wrong channel ID / read key", "ThingSpeak outage or rate limit"],
}
ACTIONS = {
    "voltage_anomaly": "Check the supply and connections, and verify the sensor against a trusted meter before drawing conclusions.",
    "high_power": "Identify which appliances were running at this time and whether all were needed.",
    "excess_energy": "Compare with the usual pattern for this hour; look for equipment left on. Mark as confirmed waste only after checking.",
    "connection_failure": "Check the ESP32 power and Wi-Fi, ThingSpeak channel ID and read key, then retry the sync.",
}


def decorate(a):
    a = dict(a)
    t = a["alert_type"]
    m, e = a.get("measured_value"), a.get("expected_value")
    a.update(label=LABELS[t], unit=UNITS[t], causes=CAUSES[t], suggested_action=ACTIONS[t],
             category="confirmed_waste" if a["status"] == "confirmed_waste" else t,
             deviation=None if m is None or e is None else m - e,
             deviation_pct=None if m is None or not e else (m - e) / e * 100)
    return a


def _sev(ratio, lo, hi):
    return "Low" if ratio < lo else "Medium" if ratio < hi else "High"


def voltage_alerts(df, st, base):
    out, thr, N = [], st["voltage_threshold_pct"], st["consecutive_readings"]
    if not base:
        return out
    for _, g in df.groupby("device_id"):
        run = []
        for ts, v in zip(g["ts"], g["voltage"]):
            if pd.isna(v):
                continue
            dev = (v - base) / base * 100
            run = run + [dev] if abs(dev) > thr else []
            if len(run) == N:
                worst = max(run, key=abs)
                out.append(dict(timestamp=A.iso(ts), alert_type="voltage_anomaly", measured_value=float(v),
                                expected_value=base, severity=_sev(abs(worst) / thr, 1.5, 2.5),
                                description=(f"Voltage {v:.1f} V was outside the baseline {base:.1f} V by more than ±{thr:g}% for "
                                             f"{N} consecutive readings (worst {worst:+.1f}%). This is a voltage deviation only; "
                                             "it does not by itself show electricity waste.")))
    return out


def power_alerts(df, st):
    out, thr = [], st["high_power_w"]
    for _, g in df.groupby("device_id"):
        prev = False
        for ts, p, ex in zip(g["ts"], g["power"], g["expected_power"]):
            hi = pd.notna(p) and p > thr
            if hi and not prev:
                out.append(dict(timestamp=A.iso(ts), alert_type="high_power", measured_value=float(p),
                                expected_value=float(ex) if pd.notna(ex) else thr,
                                severity=_sev(p / thr, 1.25, 1.5),
                                description=(f"Measured power {p:.0f} W exceeded the configured limit of {thr:.0f} W. "
                                             "Check which loads were on; the reading may also reflect sensor calibration.")))
            prev = hi
    return out


def excess_alerts(hourly, st):
    s = hourly.dropna()
    if len(s) < 24 * 7:
        return []
    out, z, ratio = [], st["excess_zscore"], st["excess_min_ratio"]
    for hr, g in s.groupby(s.index.hour):
        prev = g.shift(1)
        mean = prev.expanding(min_periods=5).mean()
        sd = np.maximum(prev.expanding(min_periods=5).std().fillna(0), 0.02)
        zs = (g - mean) / sd
        flag = (zs > z) & (g > mean * ratio) & ((g - mean) > 0.05)
        for t in g.index[flag]:
            out.append(dict(timestamp=A.iso(t), alert_type="excess_energy", measured_value=float(g[t]),
                            expected_value=float(mean[t]), severity=_sev(float(zs[t]), z * 1.5, z * 2.5),
                            description=(f"Consumption in the hour starting {t:%H:%M} was {g[t]:.2f} kWh versus a typical {mean[t]:.2f} kWh "
                                         f"for this hour (z-score {zs[t]:.1f}). Unusual, but waste is only confirmed after investigation.")))
    return out


def store_alerts(conn, alerts, source):
    new = []
    for a in alerts:
        cur = conn.execute(
            "INSERT OR IGNORE INTO alerts(timestamp,alert_type,severity,measured_value,expected_value,description,status,data_source) "
            "VALUES(?,?,?,?,?,?,'open',?)",
            (a["timestamp"], a["alert_type"], a["severity"], a.get("measured_value"), a.get("expected_value"),
             a["description"], source))
        if cur.rowcount:
            new.append(a)
    conn.commit()
    return new


def refresh_alerts(conn, cfg, st, rebuild=False):
    df, mode = A.load_df(conn, st)
    src = A.alert_source(mode)
    if rebuild:
        conn.execute("DELETE FROM alerts WHERE status='open' AND alert_type!='connection_failure' AND data_source=?", (src,))
        conn.commit()
    if df.empty:
        return []
    base = A.get_baseline(df, st)
    hourly = A.hourly_series(df, st["timezone"])
    found = voltage_alerts(df, st, base) + power_alerts(df, st) + excess_alerts(hourly, st)
    new = store_alerts(conn, found, src)
    if mode == "live":
        for a in new:
            notify.send(cfg, st, f"⚠️ {LABELS[a['alert_type']]} ({a['severity']})\n{a['description']}\nTime: {a['timestamp']}")
        state, _ = A.voltage_state(df, st, base)
        was = db.get_state(conn, "voltage_state", "normal")
        now = "anomaly" if state == "anomaly" else "normal"
        if was == "anomaly" and now == "normal":
            notify.send(cfg, st, f"✅ Recovery: voltage is back within ±{st['voltage_threshold_pct']:g}% of the baseline.")
        db.set_state(conn, "voltage_state", now)
    return new

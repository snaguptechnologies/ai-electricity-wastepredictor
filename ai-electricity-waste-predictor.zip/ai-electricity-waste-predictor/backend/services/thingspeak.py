"""ThingSpeak client. Credentials come from environment variables and never reach the browser."""
import math
from datetime import datetime, timezone
import requests
from database import db
from services import detection, notify, analysis as A


class TSError(Exception):
    pass


def configured(cfg):
    return bool(cfg["TS_CHANNEL_ID"])


def _get(cfg, path, params):
    p = dict(params)
    if cfg["TS_READ_KEY"]:
        p["api_key"] = cfg["TS_READ_KEY"]
    try:
        r = requests.get(f"{cfg['TS_BASE']}/channels/{cfg['TS_CHANNEL_ID']}/{path}", params=p, timeout=10)
    except requests.Timeout:
        raise TSError("ThingSpeak request timed out")
    except requests.RequestException:
        raise TSError("Network error while contacting ThingSpeak")   # no URL: it contains the key
    if r.status_code == 429:
        raise TSError("ThingSpeak rate limit reached; try again in a minute")
    if r.status_code in (400, 401, 403, 404):
        raise TSError(f"ThingSpeak rejected the request (HTTP {r.status_code}). Check the channel ID and read API key")
    if r.status_code != 200:
        raise TSError(f"ThingSpeak returned HTTP {r.status_code}")
    try:
        data = r.json()
    except ValueError:
        raise TSError("ThingSpeak returned invalid JSON")
    if data == -1 or not isinstance(data, dict):
        raise TSError("Channel not found or private: check the channel ID and read API key")
    return data


def _num(x):
    try:
        v = float(x)
        return v if math.isfinite(v) else None
    except (TypeError, ValueError):
        return None


def parse_feed(feed, st):
    """Return a clean reading dict, or None when the feed has no usable voltage/current."""
    try:
        ts = datetime.fromisoformat(str(feed.get("created_at")).replace("Z", "+00:00")).astimezone(timezone.utc)
    except ValueError:
        return None
    v, i = _num(feed.get(st["ts_field_voltage"])), _num(feed.get(st["ts_field_current"]))
    p, e = _num(feed.get(st["ts_field_power"])), _num(feed.get(st["ts_field_energy"]))
    if e is not None and st["ts_energy_unit"] == "Wh":
        e /= 1000
    if v is not None and not 0 <= v <= 500: v = None
    if i is not None and not 0 <= i <= 100: i = None
    if p is not None and p < 0: p = None
    if e is not None and e < 0: e = None
    if v is None and i is None and p is None:
        return None
    if p is None and v is not None and i is not None:
        p = round(v * i * st["power_factor"], 2)       # estimate; documented in README
    return {"dt": ts, "timestamp": ts.strftime("%Y-%m-%dT%H:%M:%SZ"), "voltage": v, "current": i, "power": p, "energy_kwh": e}


def sync(conn, cfg, st):
    if not configured(cfg):
        raise TSError("ThingSpeak is not configured (demo mode)")
    had = conn.execute("SELECT COUNT(*) FROM readings WHERE data_source IN ('live_iot','thingspeak_history')").fetchone()[0]
    data = _get(cfg, "feeds.json", {"results": 300 if had else 8000})
    now, ins, skipped, newest = datetime.now(timezone.utc), 0, 0, None
    for f in data.get("feeds", []):
        r = parse_feed(f, st)
        if r is None:
            skipped += 1
            continue
        age = (now - r.pop("dt")).total_seconds()
        r["data_source"] = "live_iot" if age <= max(120, 3 * st["update_interval_s"]) else "thingspeak_history"
        r["device_id"] = st["device_id"]
        ins += db.insert_reading(conn, r)
        newest = max(newest or r["timestamp"], r["timestamp"])
    conn.commit()
    db.set_state(conn, "ts_last_success", db.utcnow_iso())
    db.set_state(conn, "ts_last_error", "")
    if newest:
        db.set_state(conn, "ts_last_data", newest)
    return {"fetched": len(data.get("feeds", [])), "inserted": ins, "duplicates_or_skipped": len(data.get("feeds", [])) - ins,
            "invalid": skipped}


def run_sync(conn, cfg, st):
    """Sync + alert refresh. On failure records state and raises an alert once per 10 minutes."""
    try:
        res = sync(conn, cfg, st)
    except TSError as e:
        db.set_state(conn, "ts_last_error", str(e))
        if configured(cfg):
            last = db.get_state(conn, "ts_failure_alert", "")
            if not last or (datetime.now(timezone.utc) - datetime.fromisoformat(last)).total_seconds() > 600:
                a = dict(timestamp=db.utcnow_iso(), alert_type="connection_failure", severity="Medium",
                         measured_value=None, expected_value=None, description=f"ThingSpeak sync failed: {e}")
                if detection.store_alerts(conn, [a], "iot"):
                    notify.send(cfg, st, f"⚠️ Connection failure\n{e}")
                db.set_state(conn, "ts_failure_alert", datetime.now(timezone.utc).isoformat())
        raise
    detection.refresh_alerts(conn, cfg, st)
    return res


def status(conn, cfg, st):
    if not configured(cfg):
        return {"state": "demo", "configured": False, "message": "ThingSpeak not configured: showing labelled sample data.",
                "last_success": None, "last_data": None}
    err, ok, last = (db.get_state(conn, k) for k in ("ts_last_error", "ts_last_success", "ts_last_data"))
    state, msg = "connected", "Last sync succeeded."
    if err:
        state, msg = "error", err
    elif not ok:
        state, msg = "not_synced", "Configured, but no successful sync yet. Press Sync now."
    elif last and (datetime.now(timezone.utc) - datetime.fromisoformat(last.replace("Z", "+00:00"))).total_seconds() > st["stale_after_s"]:
        state, msg = "stale", "Last sync succeeded, but the newest reading is old: the device may be offline."
    return {"state": state, "configured": True, "message": msg, "last_success": ok, "last_data": last}

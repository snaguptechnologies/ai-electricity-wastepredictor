"""Clearly-labelled simulated data: ~30 days of hourly readings with injected, known events.

Physical consistency: power = V x I x PF (PF = assumed constant power factor), and
energy_kwh is a cumulative meter value built by trapezoidal integration of power.
"""
import numpy as np
import pandas as pd
from database import db

SAMPLE_DEVICE = "SAMPLE-ESP32"


def generate(tz="Asia/Kolkata", days=30, pf=0.9, seed=42, end=None):
    rng = np.random.default_rng(seed)
    end = (pd.Timestamp.now(tz=tz) if end is None else end).floor("h")
    idx = pd.date_range(end=end, periods=days * 24 + 1, freq="h")
    n = len(idx)
    h, wk = idx.hour.values, idx.dayofweek.values >= 5
    exp = np.full(n, 140.0)
    exp += np.where((h >= 6) & (h <= 8), 350, 0)
    exp += np.where((h >= 9) & (h <= 16), np.where(wk, 300, 120), 0)
    exp += np.where((h >= 13) & (h <= 16), 500, 0)       # afternoon air-conditioning
    exp += np.where((h >= 17) & (h <= 22), 650, 0)       # evening lights / TV / cooking
    exp += np.where((h >= 22) | (h <= 5), 400, 0)        # night air-conditioning
    power = exp * (1 + rng.normal(0, 0.08, n))
    volt = np.clip(230 + rng.normal(0, 1.2, n), 215, 245)
    day = ((idx - idx[0]).total_seconds() // 86400).astype(int)
    # injected events (so the demo shows each alert category)
    power += np.where((day == 9) & np.isin(h, [18, 19, 20]), 1500, 0)      # high-power evening
    power += np.where((day == 20) & np.isin(h, [19, 20]), 1400, 0)
    power += np.where((day == 14) & (h >= 1) & (h <= 5), 900, 0)          # equipment left on overnight
    volt = np.where((day == 5) & (h >= 11) & (h <= 14), volt * 1.065, volt)  # surge
    volt = np.where((day == 17) & (h >= 3) & (h <= 5), volt * 0.93, volt)    # sag
    volt = np.where((day == 26) & (h >= 20) & (h <= 22), volt * 1.05, volt)
    volt = np.round(volt, 1)
    cur = np.round(power / (volt * pf) * (1 + rng.normal(0, 0.004, n)), 3)
    p = np.round(volt * cur * pf, 1)
    energy = np.round(np.concatenate([[0.0], np.cumsum((p[1:] + p[:-1]) / 2 / 1000)]), 3)
    ts = idx.tz_convert("UTC").strftime("%Y-%m-%dT%H:%M:%SZ")
    return pd.DataFrame({"timestamp": ts, "device_id": SAMPLE_DEVICE, "voltage": volt, "current": cur,
                         "power": p, "energy_kwh": energy, "data_source": "sample",
                         "expected_power": np.round(exp, 1)})


def seed(conn, st, cfg, reset=False):
    """Insert sample data if the DB has no readings (or when reset=True). Returns True if seeded."""
    if reset:
        conn.execute("DELETE FROM readings WHERE data_source='sample'")
        conn.execute("DELETE FROM alerts WHERE data_source='sample'")
        conn.execute("DELETE FROM predictions")
    elif conn.execute("SELECT COUNT(*) FROM readings").fetchone()[0] > 0:
        return False
    df = generate(st["timezone"], pf=st["power_factor"])
    for r in df.to_dict("records"):
        db.insert_reading(conn, r)
    conn.commit()
    try:
        df.to_csv(cfg["SAMPLE_CSV"], index=False)
    except OSError:
        pass
    return True

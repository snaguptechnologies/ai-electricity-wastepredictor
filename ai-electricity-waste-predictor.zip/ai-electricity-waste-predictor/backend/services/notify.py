"""Telegram notifications, sent from the backend only. Never logs the bot token."""
import logging
import requests

log = logging.getLogger(__name__)


def configured(cfg):
    return bool(cfg.get("TELEGRAM_BOT_TOKEN") and cfg.get("TELEGRAM_CHAT_ID"))


def send(cfg, st, text):
    if not st.get("telegram_notifications") or not configured(cfg):
        return False
    try:
        r = requests.post(f"https://api.telegram.org/bot{cfg['TELEGRAM_BOT_TOKEN']}/sendMessage",
                          json={"chat_id": cfg["TELEGRAM_CHAT_ID"], "text": text[:3500]}, timeout=10)
        return r.status_code == 200
    except requests.RequestException:
        log.warning("Telegram notification failed")
        return False

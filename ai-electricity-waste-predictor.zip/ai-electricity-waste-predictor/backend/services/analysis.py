"""Shared data loading + analytics used by dashboard, waste detection and recommendations."""
import math
from datetime import datetime, timezone
import numpy as np, pandas as pd
from ml import forecast

NUMERIC = ["voltage", "current", "power", "energy_kwh", "expected_power"]


def jsonable(o):
    if isinstance(o, dict):
        return {k: jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (float, np.floating)):
        return float(o) if math.isfinite(float(o)) else None
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.bool_):
        return bool(o)
    if isinstance(o, pd.Timestamp):
        return iso(o)
    return o


def iso(ts):
    ts = pd.Timestamp(ts)
    ts = ts.tz_localize("UTC") if ts.tzinfo is None else ts.tz_convert("UTC")
    return ts.strftime("%Y-%m-%dT%H:%M:%SZ")


def active_sources(conn):
    n = conn.execute("SELECT COUNT(*) FROM readings WHERE data_source IN ('live_iot','thingspeak_history')").fetchone()[0]
    return (("live_iot", "thingspeak_history"), "live") if n >= 24 else (("sample", "manual"), "demo")


def alert_source(mode):
    return "sample" if mode == "demo" else "iot"


def load_df(conn, st, limit=20000):
    sources, mode = active_sources(conn)
    q = ('SELECT id,timestamp,device_id,voltage,"current" AS current,power,energy_kwh,data_source,expected_power '
         f'FROM readings WHERE data_source IN ({",".join("?" * len(sources))}) ORDER BY timestamp DESC LIMIT ?')
    rows = conn.execute(q, (*sources, limit)).fetchall()
    cols = ["id", "timestamp", "device_id", "voltage", "current", "power", "energy_kwh", "data_source", "expected_power"]
    df = pd.DataFrame([tuple(r) for r in rows], columns=cols)
    if df.empty:
        df["ts"] = pd.to_datetime(pd.Series([], dtype=object), utc=True)
        df["interval_kwh"] = pd.Series([], dtype=float)
        return df, mode
    for c in NUMERIC:
        df[c] = pd.to_numeric(df[c])
    df["ts"] = pd.to_datetime(df["timestamp"], utc=True)
    df = df.sort_values("ts").reset_index(drop=True)
    iv = pd.Series(0.0, index=df.index)
    for _, g in df.groupby("device_id"):
        e = g["energy_kwh"]
        dt = g["ts"].diff().dt.total_seconds().div(3600).clip(upper=1.0)
        from_e = e.diff().clip(lower=0)
        from_p = g["power"] * dt / 1000
        iv.loc[g.index] = from_e.where(e.notna() & e.shift().notna(), from_p).fillna(0.0)
    df["interval_kwh"] = iv
    return df, mode


def hourly_series(df, tz):
    if df.empty:
        return pd.Series(dtype=float, index=pd.DatetimeIndex([], tz=tz))
    x = df.set_index(df["ts"].dt.tz_convert(tz))["interval_kwh"]
    r = x.resample("1h", closed="right", label="left")
    s = r.sum().where(r.count() > 0)
    if len(s) and x.index.max() < s.index[-1] + pd.Timedelta(hours=1) - pd.Timedelta(minutes=5):
        s = s.iloc[:-1]            # drop the still-incomplete current hour
    return s.iloc[1:]


def get_baseline(df, st):
    if st["voltage_baseline"] > 0:
        return float(st["voltage_baseline"])
    v = df["voltage"].dropna().head(st["baseline_readings"])
    return float(v.mean()) if len(v) else None


def voltage_state(df, st, base):
    if not base or df.empty:
        return "normal", 0
    run = 0
    for x in df["voltage"].dropna().iloc[::-1]:
        if abs(x - base) / base * 100 > st["voltage_threshold_pct"]:
            run += 1
        else:
            break
    return ("anomaly" if run >= st["consecutive_readings"] else "warning" if run else "normal"), run


def row_status(v, p, st, base):
    if base and v is not None and not pd.isna(v) and abs(v - base) / base * 100 > st["voltage_threshold_pct"]:
        return "voltage_deviation"
    if p is not None and not pd.isna(p) and p > st["high_power_w"]:
        return "high_power"
    return "normal"


def status_sql(base, st):
    if base:
        return ("CASE WHEN voltage IS NOT NULL AND ABS(voltage-?)/?*100>? THEN 'voltage_deviation' "
                "WHEN power IS NOT NULL AND power>? THEN 'high_power' ELSE 'normal' END",
                [base, base, st["voltage_threshold_pct"], st["high_power_w"]])
    return ("CASE WHEN power IS NOT NULL AND power>? THEN 'high_power' ELSE 'normal' END", [st["high_power_w"]])


def build_dashboard(conn, cfg, st, ts_status):
    df, mode = load_df(conn, st)
    out = {"mode": mode, "thingspeak": ts_status,
           "tariff": {"per_unit": st["tariff_per_unit"], "additional": st["additional_charges"]}}
    if df.empty:
        out["empty"] = True
        return out
    base = get_baseline(df, st)
    last = df.iloc[-1]
    hourly = hourly_series(df, st["timezone"])
    now = pd.Timestamp.now(tz="UTC")
    pred = forecast.run(hourly, st, cfg["MODEL_DIR"])
    vstate, run = voltage_state(df, st, base)
    src = alert_source(mode)
    recent_open = conn.execute(
        "SELECT COUNT(*) FROM alerts WHERE status='open' AND severity IN ('Medium','High') AND data_source=? AND timestamp>=?",
        (src, iso(last.ts - pd.Timedelta(days=1)))).fetchone()[0]
    high = pd.notna(last.power) and last.power > st["high_power_w"]
    system = "Anomaly" if vstate == "anomaly" else "Warning" if (vstate == "warning" or high or recent_open) else "Normal"
    last30 = float(df[df.ts >= last.ts - pd.Timedelta(days=30)]["interval_kwh"].sum())
    days_cov = min(30.0, (last.ts - df.ts.iloc[0]).total_seconds() / 86400)
    d = hourly.dropna().resample("1D").sum()
    cnt = hourly.dropna().resample("1D").count()
    daily = [{"date": t.strftime("%Y-%m-%d"), "kwh": float(v), "hours": int(cnt[t])} for t, v in d.tail(30).items()]
    tail = df.tail(96)
    recent = df.tail(8).iloc[::-1]
    alerts = [dict(r) for r in conn.execute(
        "SELECT * FROM alerts WHERE data_source=? ORDER BY timestamp DESC LIMIT 5", (src,))]
    from services import detection
    out.update({
        "empty": False,
        "latest": {"timestamp": iso(last.ts), "device_id": last.device_id, "data_source": last.data_source,
                   "voltage": last.voltage, "current": last.current, "power": last.power,
                   "energy_kwh": last.energy_kwh, "age_seconds": (now - last.ts).total_seconds()},
        "total_consumption_kwh": float(df["interval_kwh"].sum()),
        "bill": {"kwh": last30, "days_covered": days_cov,
                 "amount": last30 * st["tariff_per_unit"] + st["additional_charges"]},
        "prediction": {k: pred[k] for k in ("status", "message", "next_hour_kwh", "next_day_kwh")} | {"model": pred["model"]["name"]},
        "system_status": system, "voltage_state": vstate, "voltage_baseline": base, "consecutive_abnormal": run,
        "charts": {"readings": [{"t": iso(r.ts), "voltage": r.voltage, "current": r.current, "power": r.power}
                                for r in tail.itertuples()],
                   "daily": daily, "avp": pred["backtest"][-48:]},
        "recent_readings": [{"timestamp": iso(r.ts), "voltage": r.voltage, "current": r.current, "power": r.power,
                             "energy_kwh": r.energy_kwh, "data_source": r.data_source,
                             "status": row_status(r.voltage, r.power, st, base)} for r in recent.itertuples()],
        "recent_alerts": [detection.decorate(a) for a in alerts],
        "recommendations": recommendations(df, hourly, st, conn, src)[:4],
        "thresholds": {"voltage_pct": st["voltage_threshold_pct"], "high_power_w": st["high_power_w"]},
    })
    return out


def build_waste(conn, st):
    df, mode = load_df(conn, st)
    src = alert_source(mode)
    counts = {r["alert_type"]: r["n"] for r in conn.execute(
        "SELECT alert_type, COUNT(*) n FROM alerts WHERE data_source=? GROUP BY alert_type", (src,))}
    confirmed = conn.execute("SELECT COUNT(*) FROM alerts WHERE data_source=? AND status='confirmed_waste'", (src,)).fetchone()[0]
    out = {"mode": mode, "counts": counts, "confirmed": confirmed, "voltage": [], "profile": [], "recent24": []}
    if df.empty:
        return out
    base = get_baseline(df, st)
    out["baseline"] = base
    if base:
        out["band"] = [base * (1 - st["voltage_threshold_pct"] / 100), base * (1 + st["voltage_threshold_pct"] / 100)]
    out["voltage"] = [{"t": iso(r.ts), "v": r.voltage} for r in df.tail(200).itertuples()]
    h = hourly_series(df, st["timezone"]).dropna()
    if len(h) >= 48:
        hist, rec = h.iloc[:-24], h.iloc[-24:]
        g = hist.groupby(hist.index.hour)
        out["profile"] = [{"hour": int(k), "mean": float(g.mean()[k]), "std": float(g.std().fillna(0)[k])} for k in g.mean().index]
        out["recent24"] = [{"hour": int(t.hour), "kwh": float(v)} for t, v in rec.items()]
    return out


def recommendations(df, hourly, st, conn, src):
    rate, pct = st["tariff_per_unit"], st["saving_assumption_pct"]
    recs = []
    h = hourly.dropna()
    if len(h) >= 48:
        by = h.groupby(h.index.hour).mean()
        top = by.sort_values(ascending=False).head(3)
        hrs = ", ".join(f"{k:02d}:00" for k in sorted(top.index))
        share = float(top.sum() / by.sum() * 100)
        kwh_m = float(top.sum()) * 30 * pct / 100
        recs.append({"title": "Review your highest-consumption hours",
                     "detail": f"Your three busiest hours ({hrs}) account for about {share:.0f}% of daily use. Shifting or trimming loads then has the biggest effect.",
                     "basis": "data", "assumption": f"Assumes {pct:.0f}% less use in those hours.",
                     "saving_kwh_month": kwh_m, "saving_inr_month": kwh_m * rate})
        night = h[(h.index.hour >= 1) & (h.index.hour <= 5)]
        if len(night):
            w = float(night.mean()) * 1000
            kwh_m = w / 1000 * 5 * 30 * pct / 100
            recs.append({"title": "Cut overnight (1-5 am) standby and idle load",
                         "detail": f"Average overnight draw is about {w:.0f} W. Switch off unused computers, chargers, lights and cooling when nobody needs them.",
                         "basis": "data", "assumption": f"Assumes {pct:.0f}% of the overnight load can be switched off.",
                         "saving_kwh_month": kwh_m, "saving_inr_month": kwh_m * rate})
    n_ex = conn.execute("SELECT COUNT(*) FROM alerts WHERE data_source=? AND alert_type IN ('excess_energy','high_power') AND status='open'", (src,)).fetchone()[0]
    if n_ex:
        recs.append({"title": "Investigate unusual power consumption",
                     "detail": f"{n_ex} open high-power / excess-energy alert(s). Check which equipment ran at those times; an alert is a prompt to investigate, not proof of waste.",
                     "basis": "data", "assumption": None, "saving_kwh_month": None, "saving_inr_month": None})
    ac_kwh = 1.2 * 1 * 30
    recs += [
        {"title": "Reduce unnecessary air-conditioner running time",
         "detail": "Use a timer, set 24-26 °C and keep doors closed. Cutting one hour a day is a common, measurable step.",
         "basis": "general", "assumption": "Assumes a 1,200 W AC running 1 hour less per day for 30 days.",
         "saving_kwh_month": ac_kwh, "saving_inr_month": ac_kwh * rate},
        {"title": "Switch off unused lights and computers",
         "detail": "Turn off lights in empty rooms and shut down (not just sleep) computers overnight.",
         "basis": "general", "assumption": "Savings depend on your equipment; add it to the bill calculator to test.",
         "saving_kwh_month": None, "saving_inr_month": None},
        {"title": "Compare consumption before and after an energy-saving change",
         "detail": "Note the date you change a habit or appliance, then compare average daily kWh for 7 days before and after on the Prediction and Bill pages.",
         "basis": "general", "assumption": None, "saving_kwh_month": None, "saving_inr_month": None},
    ]
    return recs

"""Hourly energy forecasting: seasonal baseline + Random Forest, chronological split, no leakage.

Every feature for hour t uses only data from hours < t (lags / shifted rolling means).
The model is only used when it beats the baseline on the held-out (most recent) data.
"""
import copy, os
from datetime import datetime, timezone
import joblib, numpy as np, pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error

LAGS = [1, 2, 3, 24]
FEATURES = ["lag1", "lag2", "lag3", "lag24", "roll6", "roll24", "hour_sin", "hour_cos", "dow", "is_weekend"]
FRIENDLY = {"lag1": "consumption in the previous hour", "lag2": "consumption 2 hours ago",
            "lag3": "consumption 3 hours ago", "lag24": "consumption at the same hour yesterday",
            "roll6": "average of the last 6 hours", "roll24": "average of the last 24 hours",
            "hour_sin": "time of day", "hour_cos": "time of day", "dow": "day of week",
            "is_weekend": "weekend vs weekday"}
_CACHE = {}


def _iso(t):
    return t.tz_convert("UTC").strftime("%Y-%m-%dT%H:%M:%SZ")


def prepare(hourly):
    if hourly is None or len(hourly) == 0:
        return pd.Series(dtype=float)
    full = pd.date_range(hourly.index.min(), hourly.index.max(), freq="h")
    return hourly.reindex(full).interpolate(limit=6, limit_area="inside")


def make_features(s):
    df = pd.DataFrame({"y": s})
    for k in LAGS:
        df[f"lag{k}"] = s.shift(k)
    p = s.shift(1)
    df["roll6"] = p.rolling(6).mean()
    df["roll24"] = p.rolling(24).mean()
    h, d = s.index.hour, s.index.dayofweek
    df["hour_sin"], df["hour_cos"] = np.sin(2 * np.pi * h / 24), np.cos(2 * np.pi * h / 24)
    df["dow"], df["is_weekend"] = d, (d >= 5).astype(int)
    return df


def row_features(t, hist):
    h, d = t.hour, t.dayofweek
    return [hist[-1], hist[-2], hist[-3], hist[-24], float(np.mean(hist[-6:])), float(np.mean(hist[-24:])),
            np.sin(2 * np.pi * h / 24), np.cos(2 * np.pi * h / 24), d, int(d >= 5)]


def baseline_at(vals, t):
    """Average of the same hour on each of the previous (up to) 7 days."""
    v = [vals.get(t - pd.Timedelta(hours=24 * k)) for k in range(1, 8)]
    v = [x for x in v if x is not None and not np.isnan(x)]
    return float(np.mean(v)) if v else float("nan")


def _metrics(y, p):
    return {"mae": float(mean_absolute_error(y, p)), "rmse": float(np.sqrt(mean_squared_error(y, p)))}


def _forecast_baseline(s, vals, H):
    last, ext, out = s.index[-1], dict(vals), []
    fallback = float(s.mean())
    for i in range(1, H + 1):
        t = last + pd.Timedelta(hours=i)
        y = baseline_at(ext, t)
        y = fallback if np.isnan(y) else y
        ext[t] = y
        out.append((t, y))
    return out


def _forecast_model(model, s, H):
    last = s.index[-1]
    hist = list(s.ffill().bfill().iloc[-48:].values)
    out = []
    for i in range(1, H + 1):
        t = last + pd.Timedelta(hours=i)
        y = max(float(model.predict(pd.DataFrame([row_features(t, hist)], columns=FEATURES))[0]), 0.0)
        hist.append(y)
        out.append((t, y))
    return out


def run(hourly, st, model_dir, force=False):
    s = prepare(hourly)
    key = (len(s), str(s.index[-1]) if len(s) else None, round(float(s.sum()), 4) if len(s) else 0,
           st["min_train_hours"], st["test_fraction"])
    if not force and key in _CACHE:
        return copy.deepcopy(_CACHE[key])
    res = _compute(s, st, model_dir)
    _CACHE.clear()
    _CACHE[key] = res
    return copy.deepcopy(res)


def _compute(s, st, model_dir):
    valid = int(s.notna().sum()) if len(s) else 0
    res = {"status": "insufficient_data", "history_hours": valid, "forecast": [], "next_hour_kwh": None,
           "next_day_kwh": None, "seven_day": None, "backtest": [], "history": [],
           "metrics": {"baseline": None, "model": None, "test_rows": 0, "evaluation": None},
           "model": {"name": "none", "type": "none", "trained": False},
           "explanation": "", "data_through": None,
           "message": (f"Only {valid} valid hourly values are available. At least 48 hours (2 days) are needed "
                       f"for a baseline forecast and {st['min_train_hours']} hours plus a hold-out period for the "
                       "machine-learning model. No prediction is shown.")}
    if valid < 48:
        return res
    vals = s.dropna().to_dict()
    span_h = len(s)
    H = 168 if span_h >= 24 * 14 else 48
    feats = make_features(s).dropna()
    n = len(feats)
    n_test = int(n * st["test_fraction"])
    selected, model, imp = "baseline", None, {}
    metrics = res["metrics"]
    if n_test >= 24 and n - n_test >= 24:
        train, test = feats.iloc[: n - n_test], feats.iloc[n - n_test:]            # chronological split
        bp = pd.Series({t: baseline_at(vals, t) for t in test.index})
        mask = bp.notna()
        y = test["y"][mask]
        metrics["baseline"] = _metrics(y, bp[mask])
        metrics["test_rows"] = int(mask.sum())
        metrics["evaluation"] = (f"One-step-ahead (next hour) error on the most recent "
                                 f"{int(st['test_fraction']*100)}% of history, never seen in training.")
        mp = None
        if n >= st["min_train_hours"]:
            m = RandomForestRegressor(n_estimators=100, min_samples_leaf=2, random_state=42, n_jobs=1)
            m.fit(train[FEATURES], train["y"])
            mp = pd.Series(m.predict(test[FEATURES]), index=test.index)[mask]
            metrics["model"] = _metrics(y, mp)
            if metrics["model"]["mae"] < metrics["baseline"]["mae"]:
                selected = "random_forest"
        bt = test[mask].tail(72)
        res["backtest"] = [{"timestamp": _iso(t), "actual": float(bt.loc[t, "y"]), "baseline": float(bp[t]),
                            "model": float(mp[t]) if mp is not None else None} for t in bt.index]
    if selected == "random_forest":
        model = RandomForestRegressor(n_estimators=100, min_samples_leaf=2, random_state=42, n_jobs=1)
        model.fit(feats[FEATURES], feats["y"])        # refit on all history for the live forecast
        out = _forecast_model(model, s, H)
        imp = sorted(zip(FEATURES, model.feature_importances_), key=lambda x: -x[1])
        os.makedirs(model_dir, exist_ok=True)
        joblib.dump({"model": model, "features": FEATURES, "metrics": metrics,
                     "trained_at": datetime.now(timezone.utc).isoformat()}, os.path.join(model_dir, "forecast.joblib"))
        names = []
        for f, _ in imp:
            if FRIENDLY[f] not in names:
                names.append(FRIENDLY[f])
        res["model"] = {"name": "Random Forest regression", "type": "random_forest", "trained": True,
                        "train_rows": n, "features": FEATURES, "top_factors": names[:4],
                        "trained_at": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")}
        res["status"] = "ok"
        res["explanation"] = ("The forecast comes from a Random Forest trained on this site's hourly history. "
                              "It looks at: " + ", ".join(names[:4]) + ". It beat the simple baseline on held-out data, "
                              "but multi-hour forecasts feed their own predictions back in, so errors grow with distance.")
        res["message"] = "Random Forest model trained and evaluated on held-out data."
    else:
        out = _forecast_baseline(s, vals, H)
        res["model"] = {"name": "Seasonal baseline (same-hour average of previous 7 days)", "type": "baseline", "trained": False}
        res["status"] = "baseline_only"
        why = ("history is too short to train the ML model (needs "
               f"{st['min_train_hours']} usable hours)" if metrics["model"] is None and n < st["min_train_hours"]
               else "the ML model did not beat the baseline on held-out data" if metrics["model"] else
               "history is too short to evaluate a model")
        res["explanation"] = ("Prediction = average consumption at the same hour of day over the previous (up to) 7 days. "
                              f"A machine-learning model is not in use because {why}.")
        res["message"] = "Baseline forecast in use; no trained AI model is running."
        if metrics["baseline"] is None:
            res["message"] += " Not enough history to compute an accuracy metric."
    res["forecast"] = [{"timestamp": _iso(t), "kwh": y} for t, y in out]
    res["next_hour_kwh"] = out[0][1]
    res["next_day_kwh"] = float(sum(y for _, y in out[:24]))
    if H == 168:
        res["seven_day"] = [{"block": k + 1, "start": _iso(out[k * 24][0]),
                             "kwh": float(sum(y for _, y in out[k * 24:(k + 1) * 24]))} for k in range(7)]
    hist = s.tail(168)
    res["history"] = [{"timestamp": _iso(t), "kwh": None if np.isnan(v) else float(v)} for t, v in hist.items()]
    res["data_through"] = _iso(s.index[-1] + pd.Timedelta(hours=1))
    return res

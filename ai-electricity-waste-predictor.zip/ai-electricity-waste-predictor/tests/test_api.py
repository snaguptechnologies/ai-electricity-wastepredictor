import io
from services import thingspeak as ts


def test_health_and_demo_mode(client):
    r = client.get("/api/health").get_json()
    assert r["status"] == "ok" and r["thingspeak"]["state"] == "demo"


def test_dashboard_consistent_and_labelled(client):
    d = client.get("/api/dashboard").get_json()
    assert d["mode"] == "demo" and d["latest"]["data_source"] == "sample"
    assert d["total_consumption_kwh"] > 100
    assert d["prediction"]["next_day_kwh"] > 0
    assert d["system_status"] in ("Normal", "Warning", "Anomaly")


def test_sample_alert_categories(client):
    types = {a["alert_type"] for a in client.get("/api/alerts").get_json()["alerts"]}
    assert {"voltage_anomaly", "high_power", "excess_energy"} <= types


def test_prediction_honest_and_chronological(client):
    p = client.get("/api/predictions").get_json()
    assert p["status"] in ("ok", "baseline_only")
    assert p["metrics"]["baseline"]["mae"] > 0
    if p["status"] == "baseline_only":
        assert p["model"]["trained"] is False
    assert len(p["seven_day"]) == 7
    r = client.post("/api/predict", json={"horizon_hours": 0})
    assert r.status_code == 422
    assert len(client.post("/api/predict", json={"horizon_hours": 12}).get_json()["forecast"]) == 12


def test_manual_reading_validation_and_duplicates(client):
    bad = client.post("/api/readings", json={"voltage": 9999, "current": "x"})
    assert bad.status_code == 422 and "voltage" in bad.get_json()["details"]
    good = {"timestamp": "2024-01-01T10:00", "voltage": 231.2, "current": 2.5, "energy_kwh": 1.0}
    assert client.post("/api/readings", json=good).status_code == 201
    assert client.post("/api/readings", json=good).status_code == 409


def test_device_key_required_when_header_sent(client):
    d = {"timestamp": "2024-02-01T10:00", "voltage": 230, "current": 1}
    assert client.post("/api/readings", json=d, headers={"X-API-Key": "wrong"}).status_code == 401
    r = client.post("/api/readings", json=d, headers={"X-API-Key": "secret-key"})
    assert r.status_code == 201 and r.get_json()["reading"]["data_source"] == "live_iot"


def test_readings_filter_sort_export_import(client):
    r = client.get("/api/readings?sort=power&order=desc&per_page=5&source=sample").get_json()
    p = [x["power"] for x in r["readings"]]
    assert p == sorted(p, reverse=True) and r["total"] > 700
    assert client.get("/api/readings?sort=bogus").status_code == 400
    csv_text = client.get("/api/readings/export?source=sample").data.decode()
    assert csv_text.startswith("timestamp,device_id")
    up = client.post("/api/readings/import", data={"file": (io.BytesIO(b"timestamp,voltage,current\n2024-03-01T10:00,230,1\nbad,1,1\n"), "x.csv")},
                     content_type="multipart/form-data").get_json()
    assert up["inserted"] == 1 and up["rejected"] == 1


def test_alert_review_and_settings(client):
    a = client.get("/api/alerts").get_json()["alerts"][0]
    r = client.patch(f"/api/alerts/{a['id']}", json={"status": "reviewed"}).get_json()
    assert r["alert"]["status"] == "reviewed"
    assert client.patch(f"/api/alerts/{a['id']}", json={"status": "nope"}).status_code == 422
    assert client.patch("/api/alerts/999999", json={"status": "open"}).status_code == 404
    s = client.put("/api/settings", json={"voltage_threshold_pct": 10}).get_json()
    assert s["values"]["voltage_threshold_pct"] == 10
    assert client.put("/api/settings", json={"voltage_threshold_pct": -1, "evil": 1}).status_code == 422


def test_settings_never_expose_secrets(client):
    t = client.get("/api/settings").get_data(as_text=True)
    assert "secret-key" not in t


def test_sync_not_configured_and_parse():
    st = {"ts_field_voltage": "field1", "ts_field_current": "field2", "ts_field_power": "field3", "ts_field_energy": "field4",
          "ts_energy_unit": "Wh", "power_factor": 0.9}
    r = ts.parse_feed({"created_at": "2025-01-01T10:00:00Z", "field1": "230", "field2": "2", "field3": None, "field4": "1500"}, st)
    assert r["power"] == 414.0 and r["energy_kwh"] == 1.5
    assert ts.parse_feed({"created_at": "2025-01-01T10:00:00Z", "field1": "abc"}, st) is None


def test_sync_endpoint(client, app, monkeypatch):
    assert client.post("/api/thingspeak/sync").status_code == 503
    app.config["TS_CHANNEL_ID"] = "123"
    from datetime import datetime, timezone, timedelta
    now = datetime.now(timezone.utc)
    feeds = [{"created_at": (now - timedelta(minutes=m)).strftime("%Y-%m-%dT%H:%M:%SZ"), "field1": "230.5", "field2": "1.2", "field3": "250", "field4": str(10 - m / 100)} for m in range(40)]
    monkeypatch.setattr(ts, "_get", lambda cfg, path, params: {"feeds": feeds})
    r1 = client.post("/api/thingspeak/sync").get_json()
    r2 = client.post("/api/thingspeak/sync").get_json()
    assert r1["inserted"] == 40 and r2["inserted"] == 0
    assert client.get("/api/dashboard").get_json()["mode"] == "live"
    def boom(cfg, path, params): raise ts.TSError("rate limit")
    monkeypatch.setattr(ts, "_get", boom)
    assert client.post("/api/thingspeak/sync").status_code == 502
    assert client.get("/api/health").get_json()["thingspeak"]["state"] == "error"


def test_json_404(client):
    assert client.get("/api/nope").get_json()["error"] == "Not found"

import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))
import pytest
from app import create_app


@pytest.fixture()
def app(tmp_path):
    return create_app({"DB_PATH": str(tmp_path / "t.db"), "MODEL_DIR": str(tmp_path / "m"), "SAMPLE_CSV": str(tmp_path / "s.csv"),
                       "TESTING": True, "TS_CHANNEL_ID": "", "DEVICE_API_KEY": "secret-key"})


@pytest.fixture()
def client(app):
    return app.test_client()

/* AI Electricity Waste Predictor - single-page frontend (no secrets live here; all data via /api) */
const $ = (s, r = document) => r.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const n = (v, d = 1) => v == null || Number.isNaN(+v) ? '—' : (+v).toLocaleString('en-IN', { minimumFractionDigits: d, maximumFractionDigits: d });
const inr = v => v == null ? '—' : '₹' + (+v).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const tf = i => i ? new Date(i).toLocaleString('en-IN', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' }) : '—';
const hf = i => new Date(i).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
const SRC = { live_iot: ['Live IoT', 'ok'], thingspeak_history: ['Historical ThingSpeak', 'info'], manual: ['Manually entered', 'mute'], sample: ['Simulated sample', 'warn'] };
const SEV = { Low: 'info', Medium: 'warn', High: 'bad' };
const STAT = { normal: ['Normal', 'ok'], voltage_deviation: ['Voltage deviation', 'warn'], high_power: ['High power', 'bad'] };
const ASTAT = { open: 'Open', reviewed: 'Reviewed', confirmed_waste: 'Confirmed waste', resolved: 'Resolved' };
const pill = (t, c) => `<span class="pill ${c}">${esc(t)}</span>`;
const srcPill = s => pill(...(SRC[s] || [s, 'mute']));
const icon = i => `<i data-lucide="${i}"></i>`;
let charts = {}, timer = null, TSCONF = false;

async function api(path, opt = {}) {
  const o = { ...opt, headers: opt.body instanceof FormData ? {} : { 'Content-Type': 'application/json' } };
  let r; try { r = await fetch('/api' + path, o); } catch { throw Object.assign(new Error('Cannot reach the backend. Is it running?'), { status: 0 }); }
  let d = null; try { d = await r.json(); } catch { }
  if (!r.ok) throw Object.assign(new Error(d?.error || r.statusText), { status: r.status, details: d?.details });
  return d;
}
function toast(msg, bad) { const t = document.createElement('div'); t.className = 'toast' + (bad ? ' bad' : ''); t.textContent = msg; $('#toasts').append(t); setTimeout(() => t.remove(), 4500); }
function mk(id, cfg) {
  const c = document.getElementById(id); if (!c) return; charts[id]?.destroy();
  cfg.options = { responsive: true, maintainAspectRatio: false, interaction: { mode: 'index', intersect: false }, ...cfg.options };
  charts[id] = new Chart(c, cfg);
}
const ds = (label, data, color, x = {}) => ({ label, data, borderColor: color, backgroundColor: color.length === 7 ? color + '33' : color, borderWidth: 2, pointRadius: 0, tension: .3, spanGaps: true, ...x });
const chartBox = (id, tall) => `<div class="chart ${tall ? 'tall' : ''}"><canvas id="${id}" role="img" aria-label="${id} chart"></canvas></div>`;
function banner(mode) {
  return mode === 'demo' ? `<div class="banner" role="note">${icon('flask-conical')}<div><b>Demo mode: simulated sample data.</b> These are generated example readings, not measurements from your device. Configure ThingSpeak (Device &amp; Settings) to see real readings.</div></div>` : '';
}
function setMode(mode) { const b = $('#modebadge'); b.className = 'pill ' + (mode === 'demo' ? 'warn' : 'ok'); b.textContent = mode === 'demo' ? 'Demo data' : 'Live IoT data'; }
const metric = (ic, l, v, u, sub) => `<div class="card metric"><div class="lbl">${icon(ic)}${l}</div><div class="val">${v}${u ? `<small>${u}</small>` : ''}</div>${sub ? `<div class="sub">${sub}</div>` : ''}</div>`;
const tsInfo = t => ({ demo: ['Not configured (demo)', 'warn'], connected: ['Connected', 'ok'], stale: ['Connected, data stale', 'warn'], error: ['Error', 'bad'], not_synced: ['Not yet synced', 'warn'] }[t.state] || [t.state, 'mute']);

/* ------------------------------------------------ Dashboard */
async function pgDashboard(v, quiet) {
  const d = await api('/dashboard'); setMode(d.mode); TSCONF = d.thingspeak.configured;
  if (d.empty) { v.innerHTML = banner(d.mode) + '<div class="card empty">No readings yet. Add a manual reading or sync ThingSpeak.</div>'; return; }
  const L = d.latest, p = d.prediction, [tsT, tsC] = tsInfo(d.thingspeak);
  const sc = { Normal: 'ok', Warning: 'warn', Anomaly: 'bad' }[d.system_status];
  const stale = L.age_seconds > 3600 ? `${Math.round(L.age_seconds / 3600)} h ago` : `${Math.round(L.age_seconds / 60)} min ago`;
  v.innerHTML = banner(d.mode) + `
  <div class="bar"><div style="flex:1"><p class="muted small">Device ${esc(L.device_id)} · latest reading source: ${srcPill(L.data_source)}</p></div>
    ${TSCONF ? `<button class="btn ghost sm" id="sync">${icon('refresh-cw')}Sync ThingSpeak now</button>` : ''}</div>
  <div class="grid metrics">
    ${metric('activity', 'Voltage', n(L.voltage), 'V', `baseline ${n(d.voltage_baseline)} V`)}
    ${metric('gauge', 'Current', n(L.current, 3), 'A')}
    ${metric('zap', 'Power', n(L.power, 0), 'W', `limit ${n(d.thresholds.high_power_w, 0)} W`)}
    ${metric('battery-charging', 'Total energy recorded', n(d.total_consumption_kwh, 2), 'kWh', 'over the stored period')}
    ${metric('indian-rupee', 'Estimated bill', inr(d.bill.amount), '', `last ${n(d.bill.days_covered, 0)} days · ${n(d.bill.kwh, 1)} kWh · estimate`)}
    ${metric('clock', 'Next-hour forecast', n(p.next_hour_kwh, 3), 'kWh', esc(p.model))}
    ${metric('calendar-days', 'Next-day forecast', n(p.next_day_kwh, 2), 'kWh', 'sum of next 24 h')}
    ${metric('shield-check', 'System status', pill(d.system_status, sc), '', d.consecutive_abnormal ? `${d.consecutive_abnormal} abnormal voltage reading(s) in a row` : 'voltage within threshold')}
    ${metric('cloud', 'ThingSpeak', pill(tsT, tsC), '', esc(d.thingspeak.message))}
    ${metric('timer', 'Last sensor update', stale, '', tf(L.timestamp))}
  </div>
  ${p.status !== 'ok' ? `<div class="banner info">${icon('info')}<div>${esc(p.message)}</div></div>` : ''}
  <div class="grid g2"><div class="card"><h2>Voltage history (V)</h2>${chartBox('cV')}</div><div class="card"><h2>Current history (A)</h2>${chartBox('cI')}</div></div>
  <div class="grid g2"><div class="card"><h2>Power history (W)</h2>${chartBox('cP')}</div><div class="card"><h2>Energy consumption by day (kWh)</h2>${chartBox('cD')}</div></div>
  <div class="card" style="margin-bottom:14px"><h2>Actual vs predicted hourly consumption (held-out data)</h2>${chartBox('cA')}<p class="hint">Predictions were made one hour ahead for hours the model had not seen.</p></div>
  <div class="grid g2">
    <div class="card"><h2>Recent readings</h2><div class="tw"><table><thead><tr><th>Time</th><th>V</th><th>A</th><th>W</th><th>Source</th><th>Status</th></tr></thead><tbody>
      ${d.recent_readings.map(r => `<tr><td>${tf(r.timestamp)}</td><td>${n(r.voltage)}</td><td>${n(r.current, 3)}</td><td>${n(r.power, 0)}</td><td>${srcPill(r.data_source)}</td><td>${pill(...STAT[r.status])}</td></tr>`).join('')}</tbody></table></div></div>
    <div class="card"><h2>Recent alerts</h2>${d.recent_alerts.length ? d.recent_alerts.map(a => `<p>${pill(a.severity, SEV[a.severity])} <b>${esc(a.label)}</b> <span class="muted small">${tf(a.timestamp)} · ${ASTAT[a.status]}</span></p>`).join('') : '<p class="muted">No alerts.</p>'}<p><a href="#alerts">View all alerts</a></p></div>
  </div>
  <div class="card"><h2>Energy-saving suggestions</h2>${recList(d.recommendations)}<p><a href="#recommendations">More suggestions</a></p></div>`;
  const R = d.charts.readings, lab = R.map(r => tf(r.t));
  const band = d.voltage_baseline ? [d.voltage_baseline * (1 - d.thresholds.voltage_pct / 100), d.voltage_baseline * (1 + d.thresholds.voltage_pct / 100)] : null;
  mk('cV', { type: 'line', data: { labels: lab, datasets: [ds('Voltage (V)', R.map(r => r.voltage), '#22d3ee'), ...(band ? [ds('Upper limit', R.map(() => band[1]), '#fbbf2488', { borderDash: [5, 4], borderWidth: 1 }), ds('Lower limit', R.map(() => band[0]), '#fbbf2488', { borderDash: [5, 4], borderWidth: 1 })] : [])] }, options: { scales: { x: { ticks: { maxTicksLimit: 6 } } } } });
  mk('cI', { type: 'line', data: { labels: lab, datasets: [ds('Current (A)', R.map(r => r.current), '#3b82f6', { fill: true })] }, options: { scales: { x: { ticks: { maxTicksLimit: 6 } } } } });
  mk('cP', { type: 'line', data: { labels: lab, datasets: [ds('Power (W)', R.map(r => r.power), '#34d399', { fill: true }), ds('Limit', R.map(() => d.thresholds.high_power_w), '#f8717188', { borderDash: [5, 4], borderWidth: 1 })] }, options: { scales: { x: { ticks: { maxTicksLimit: 6 } } } } });
  mk('cD', { type: 'bar', data: { labels: d.charts.daily.map(x => x.date.slice(5)), datasets: [{ label: 'kWh', data: d.charts.daily.map(x => x.kwh), backgroundColor: d.charts.daily.map(x => x.hours < 20 ? '#3b82f655' : '#22d3ee') }] }, options: { plugins: { legend: { display: false } } } });
  avpChart('cA', d.charts.avp);
  $('#sync')?.addEventListener('click', async e => { e.target.disabled = true; try { const r = await api('/thingspeak/sync', { method: 'POST' }); toast(`Synced: ${r.inserted} new reading(s)`); navigate(); } catch (x) { toast(x.message, true); e.target.disabled = false; } });
}
function avpChart(id, bt) {
  if (!bt?.length) { const c = document.getElementById(id); if (c) c.parentElement.innerHTML = '<p class="empty">Not enough history to evaluate predictions yet.</p>'; return; }
  mk(id, { type: 'line', data: { labels: bt.map(b => tf(b.timestamp)), datasets: [ds('Actual', bt.map(b => b.actual), '#e6eefc'), ds('Baseline (same hour, last 7 days)', bt.map(b => b.baseline), '#fbbf24', { borderDash: [4, 3] }), ...(bt[0].model != null ? [ds('ML model', bt.map(b => b.model), '#22d3ee')] : [])] }, options: { scales: { x: { ticks: { maxTicksLimit: 8 } }, y: { title: { display: true, text: 'kWh per hour' } } } } });
}
function recList(rs) {
  return rs.map(r => `<div class="rec">${icon('lightbulb')}<div><b>${esc(r.title)}</b><p class="muted">${esc(r.detail)}</p>${r.saving_kwh_month != null ? `<p class="small">Estimated saving: <b>${n(r.saving_kwh_month, 1)} kWh</b> ≈ <b>${inr(r.saving_inr_month)}</b> per month. <span class="muted">${esc(r.assumption || '')} Estimate, not guaranteed.</span></p>` : r.assumption ? `<p class="small muted">${esc(r.assumption)}</p>` : ''}</div></div><hr style="border:0;border-top:1px solid var(--line);margin:10px 0">`).join('');
}

/* ------------------------------------------------ Prediction */
async function pgPrediction(v) {
  const p = await api('/predictions'); setMode(p.mode);
  const m = p.metrics, mb = m.baseline, mm = m.model;
  const draw = p => {
    if (!p.forecast.length) return;
    const H = p.history, F = p.forecast, labs = [...H.map(x => tf(x.timestamp)), ...F.map(x => tf(x.timestamp))];
    mk('cH', { type: 'line', data: { labels: labs, datasets: [ds('History (kWh/h)', [...H.map(x => x.kwh), ...F.map(() => null)], '#22d3ee'), ds('Forecast (kWh/h)', [...H.map(() => null), ...F.map(x => x.kwh)], '#34d399', { borderDash: [6, 4] })] }, options: { scales: { x: { ticks: { maxTicksLimit: 8 } } } } });
    avpChart('cB', p.backtest);
  };
  v.innerHTML = banner(p.mode) + `
  <div class="banner ${p.status === 'ok' ? 'info' : ''}">${icon(p.status === 'ok' ? 'brain-circuit' : 'info')}<div><b>${esc(p.model.name)}</b>: ${esc(p.message)}</div></div>
  <div class="bar"><label>Forecast horizon<select id="hz"><option value="24">Next 24 hours</option><option value="72">Next 3 days</option><option value="168">Next 7 days</option></select></label>
  <button class="btn" id="refresh">${icon('refresh-cw')}Refresh prediction</button></div>
  <div class="grid metrics">
    ${metric('clock', 'Next hour', n(p.next_hour_kwh, 3), 'kWh')}
    ${metric('calendar-days', 'Next day', n(p.next_day_kwh, 2), 'kWh')}
    ${metric('ruler', 'Baseline MAE', mb ? n(mb.mae, 4) : '—', 'kWh/h', mb ? `RMSE ${n(mb.rmse, 4)}` : 'not enough data')}
    ${metric('brain', 'ML model MAE', mm ? n(mm.mae, 4) : '—', 'kWh/h', mm ? `RMSE ${n(mm.rmse, 4)}` : 'model not trained')}
  </div>
  <div class="card" style="margin-bottom:14px"><h2>Historical consumption and forecast</h2>${p.forecast.length ? chartBox('cH', 1) : '<p class="empty">Insufficient data for a forecast.</p>'}</div>
  <div class="grid g2"><div class="card"><h2>Actual vs predicted (held-out)</h2>${chartBox('cB')}<p class="hint">${esc(m.evaluation || 'No evaluation available.')}</p></div>
  <div class="card"><h2>Model information</h2><dl class="kv"><dt>Method</dt><dd>${esc(p.model.name)}</dd><dt>Trained model running</dt><dd>${p.model.trained ? 'Yes (evaluated)' : 'No'}</dd>
   <dt>Hours of history</dt><dd>${p.history_hours}</dd><dt>Test rows</dt><dd>${m.test_rows}</dd><dt>Split</dt><dd>Chronological (oldest → train, newest → test)</dd>
   <dt>Data through</dt><dd>${tf(p.data_through)}</dd></dl>
   <h3 style="margin-top:12px">Why this prediction?</h3><p class="muted">${esc(p.explanation)}</p>${p.model.top_factors ? `<ul class="clean">${p.model.top_factors.map(f => `<li>${esc(f)}</li>`).join('')}</ul>` : ''}</div></div>
  ${p.seven_day ? `<div class="card"><h2>Seven-day forecast (24-hour blocks)</h2>${chartBox('cW')}<p class="hint">Later blocks are less certain because each hour is predicted from earlier predictions.</p></div>` : ''}`;
  draw(p);
  if (p.seven_day) mk('cW', { type: 'bar', data: { labels: p.seven_day.map(b => tf(b.start)), datasets: [{ label: 'kWh', data: p.seven_day.map(b => b.kwh), backgroundColor: '#3b82f6' }] }, options: { plugins: { legend: { display: false } } } });
  $('#refresh').onclick = async e => { e.target.disabled = true; try { const r = await api('/predict', { method: 'POST', body: JSON.stringify({ horizon_hours: +$('#hz').value, retrain: true }) }); toast(`Prediction refreshed (${r.model.name})`); navigate(); } catch (x) { toast(x.message, true); e.target.disabled = false; } };
}

/* ------------------------------------------------ Waste detection */
const CATS = [['voltage_anomaly', 'Voltage anomaly', 'Supply voltage outside the baseline band for several readings in a row. A supply or sensor issue, not waste by itself.'],
['high_power', 'Unusually high power', 'Instantaneous power above your configured limit. Check which loads ran.'],
['excess_energy', 'Excess energy consumption', 'Hourly energy well above what is typical for that hour of day.'],
['confirmed_waste', 'Confirmed waste', 'Only alerts you reviewed and marked as confirmed after investigating. Needs further evidence.']];
let wf = { from: '', to: '', severity: '', type: '' };
async function pgWaste(v) {
  const w = await api('/waste'); setMode(w.mode);
  v.innerHTML = banner(w.mode) + `<div class="banner info">${icon('info')}<div>Alerts are prompts to investigate. A voltage deviation or a high reading does <b>not</b> prove electricity waste; waste is confirmed only after you check the cause.</div></div>
  <div class="grid g3">${CATS.map(([k, l, d]) => `<div class="card"><h3>${l}</h3><div class="val" style="font:700 1.8rem var(--head)">${k === 'confirmed_waste' ? w.confirmed : (w.counts[k] || 0)}</div><p class="muted small">${d}</p></div>`).join('')}</div>
  <div class="grid g2"><div class="card"><h2>Voltage vs expected band</h2>${chartBox('wV')}<p class="hint">Baseline ${n(w.baseline)} V; band ±threshold from Settings (firmware default 4%).</p></div>
  <div class="card"><h2>Last 24 h vs typical hourly profile</h2>${w.profile.length ? chartBox('wP') : '<p class="empty">Needs at least 2 days of hourly data.</p>'}<p class="hint">Typical range = mean ± 1 standard deviation of earlier days.</p></div></div>
  <div class="card"><h2>Detected events</h2>
  <div class="bar"><label>From<input type="date" id="wfrom" value="${wf.from}"></label><label>To<input type="date" id="wto" value="${wf.to}"></label>
  <label>Severity<select id="wsev"><option value="">All</option>${['Low', 'Medium', 'High'].map(s => `<option ${wf.severity === s ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
  <label>Type<select id="wtype"><option value="">All</option>${CATS.slice(0, 3).map(c => `<option value="${c[0]}" ${wf.type === c[0] ? 'selected' : ''}>${c[1]}</option>`).join('')}</select></label>
  <button class="btn ghost sm" id="wgo">Apply filters</button></div><div id="wlist"></div></div>`;
  if (w.voltage.length) mk('wV', { type: 'line', data: { labels: w.voltage.map(x => tf(x.t)), datasets: [ds('Voltage (V)', w.voltage.map(x => x.v), '#22d3ee'), ...(w.band ? [ds('Upper', w.voltage.map(() => w.band[1]), '#fbbf2488', { borderDash: [5, 4], borderWidth: 1 }), ds('Lower', w.voltage.map(() => w.band[0]), '#fbbf2488', { borderDash: [5, 4], borderWidth: 1 })] : [])] }, options: { scales: { x: { ticks: { maxTicksLimit: 6 } } } } });
  if (w.profile.length) { const rec = Object.fromEntries(w.recent24.map(r => [r.hour, r.kwh])); mk('wP', { type: 'line', data: { labels: w.profile.map(p => p.hour + ':00'), datasets: [ds('Typical + 1σ', w.profile.map(p => p.mean + p.std), '#3b82f655', { borderWidth: 1 }), ds('Typical − 1σ', w.profile.map(p => Math.max(p.mean - p.std, 0)), '#3b82f655', { borderWidth: 1, fill: '-1' }), ds('Typical', w.profile.map(p => p.mean), '#3b82f6'), ds('Last 24 h', w.profile.map(p => rec[p.hour] ?? null), '#34d399')] }, options: { scales: { y: { title: { display: true, text: 'kWh per hour' } } } } }); }
  const load = async () => {
    wf = { from: $('#wfrom').value, to: $('#wto').value, severity: $('#wsev').value, type: $('#wtype').value };
    const q = new URLSearchParams(Object.entries(wf).filter(([k, x]) => x)); let rows = [];
    try { rows = (await api('/alerts?' + q)).alerts.filter(a => a.alert_type !== 'connection_failure'); } catch (e) { toast(e.message, true); }
    $('#wlist').innerHTML = rows.length ? `<div class="tw"><table><thead><tr><th>Time</th><th>Type</th><th>Severity</th><th>Measured</th><th>Expected</th><th>Deviation</th><th>Explanation</th></tr></thead><tbody>${rows.map(a => `<tr><td>${tf(a.timestamp)}</td><td>${esc(a.category === 'confirmed_waste' ? 'Confirmed waste' : a.label)}</td><td>${pill(a.severity, SEV[a.severity])}</td><td>${n(a.measured_value, a.unit === 'kWh' ? 2 : 1)} ${a.unit}</td><td>${n(a.expected_value, a.unit === 'kWh' ? 2 : 1)} ${a.unit}</td><td>${a.deviation_pct == null ? '—' : (a.deviation_pct > 0 ? '+' : '') + n(a.deviation_pct) + '%'}</td><td class="wrap">${esc(a.description)}<br><span class="muted small">Possible causes: ${a.causes.map(esc).join('; ')}.<br>Suggested: ${esc(a.suggested_action)}</span></td></tr>`).join('')}</tbody></table></div>` : '<p class="empty">No matching events.</p>';
  };
  $('#wgo').onclick = load; load();
}

/* ------------------------------------------------ Bill calculator */
async function pgBill(v) {
  v.innerHTML = `<div class="grid g2"><div class="card"><h2>Inputs</h2><form id="bf" class="form" novalidate>
  <label>Energy consumption (kWh)<input id="b_kwh" type="number" step="any" min="0" required><span class="err" id="e_kwh"></span></label>
  <label>Cost per unit (₹/kWh)<input id="b_rate" type="number" step="any" min="0" required><span class="err" id="e_rate"></span></label>
  <label>Additional charges (₹)<input id="b_add" type="number" step="any" min="0" value="0"><span class="err" id="e_add"></span></label>
  <label>Reduction in consumption (%) <input id="b_red" type="number" step="any" min="0" max="100" value="10"><span class="err" id="e_red"></span></label>
  <label>Predicted consumption (kWh, optional)<input id="b_pred" type="number" step="any" min="0"><span class="err" id="e_pred"></span></label>
  <div style="display:flex;gap:8px;align-items:end;flex-wrap:wrap"><button class="btn" type="submit">${icon('calculator')}Calculate</button><button type="button" class="btn ghost" id="b_load">${icon('database')}Use my data</button></div></form></div>
  <div class="card"><h2>Results</h2><div id="bres" class="muted">Enter values and press Calculate.</div></div></div>
  <div class="card"><h2>How this is calculated</h2><p class="muted">Bill = kWh × cost per unit + additional charges. After reduction: kWh × (1 − reduction%) × cost per unit + additional charges. Savings = difference between the two. Actual Indian electricity bills may also include tariff slabs, fixed/demand charges, fuel adjustments, taxes, subsidies and state-specific rules, so treat this as an estimate.</p></div>`;
  const val = (id, req, max) => { const el = $('#b_' + id), e = $('#e_' + id); e.textContent = ''; if (el.value === '') { if (req) e.textContent = 'Required'; return req ? null : undefined; } const x = Number(el.value); if (!isFinite(x) || x < 0) { e.textContent = 'Enter a number ≥ 0'; return null; } if (max && x > max) { e.textContent = `Max ${max}`; return null; } return x; };
  $('#bf').onsubmit = e => {
    e.preventDefault(); const k = val('kwh', 1), r = val('rate', 1), a = val('add', 0) ?? 0, red = val('red', 0, 100) ?? 0, pr = val('pred', 0);
    if ([k, r, a, red, pr].includes(null)) return;
    const bill = k * r + a, kr = k * (1 - red / 100), br = kr * r + a;
    let h = `<div class="result"><div><span>Estimated bill</span><b>${inr(bill)}</b></div><div><span>Bill after ${n(red, 0)}% reduction (${n(kr, 2)} kWh)</span><b>${inr(br)}</b></div><div><span>Potential saving</span><b style="color:var(--green)">${inr(bill - br)}</b></div>`;
    if (pr !== undefined) { const pb = pr * r + a; h += `<div><span>Bill at predicted ${n(pr, 2)} kWh</span><b>${inr(pb)}</b></div><div><span>Predicted − actual cost</span><b>${pb - bill >= 0 ? '+' : '−'}${inr(Math.abs(pb - bill))}</b></div>`; }
    $('#bres').innerHTML = h + '</div><p class="hint">Estimate, not a guaranteed saving.</p>';
  };
  $('#b_load').onclick = async () => { try { const d = await api('/dashboard'); if (d.empty) return toast('No data yet', true); $('#b_kwh').value = d.bill.kwh.toFixed(2); $('#b_rate').value = d.tariff.per_unit; $('#b_add').value = d.tariff.additional; if (d.prediction.next_day_kwh) $('#b_pred').value = (d.prediction.next_day_kwh * d.bill.days_covered).toFixed(2); toast(`Loaded last ${n(d.bill.days_covered, 0)} days. Predicted = next-day forecast × same number of days (a rough projection).`); } catch (x) { toast(x.message, true); } };
}

/* ------------------------------------------------ Recommendations */
async function pgRecs(v) {
  const r = await api('/recommendations'); setMode(r.mode);
  v.innerHTML = banner(r.mode) + `<div class="card"><h2>Energy-saving recommendations</h2><p class="muted small">${esc(r.note)} Tariff and the assumed percentage come from Settings.</p>${recList(r.recommendations)}</div>`;
}

/* ------------------------------------------------ Readings */
let rf = { page: 1, sort: 'timestamp', order: 'desc', q: '', from: '', to: '', source: '', status: '' };
async function pgReadings(v) {
  v.innerHTML = `<details class="card"><summary>${icon('plus-circle')} Add a manual reading</summary><form id="mf" class="form" novalidate>
   <label>Date &amp; time<input name="timestamp" type="datetime-local"></label><label>Voltage (V)*<input name="voltage" type="number" step="any" required></label>
   <label>Current (A)*<input name="current" type="number" step="any" required></label><label>Power (W)<input name="power" type="number" step="any"><span class="hint">Blank = V × I × power factor (estimate)</span></label>
   <label>Energy (kWh, cumulative)<input name="energy_kwh" type="number" step="any"></label><label>Device ID<input name="device_id" placeholder="default device"></label>
   <div style="align-self:end"><button class="btn" type="submit">Save reading</button></div><div id="merr" class="err" style="grid-column:1/-1"></div></form></details>
  <div class="card"><div class="bar"><label>Search<input id="rq" type="search" placeholder="device, source, value…" value="${esc(rf.q)}"></label>
   <label>From<input id="rfrom" type="date" value="${rf.from}"></label><label>To<input id="rto" type="date" value="${rf.to}"></label>
   <label>Source<select id="rsrc"><option value="">All</option>${Object.entries(SRC).map(([k, s]) => `<option value="${k}" ${rf.source === k ? 'selected' : ''}>${s[0]}</option>`).join('')}</select></label>
   <label>Status<select id="rst"><option value="">All</option>${Object.entries(STAT).map(([k, s]) => `<option value="${k}" ${rf.status === k ? 'selected' : ''}>${s[0]}</option>`).join('')}</select></label>
   <button class="btn ghost sm" id="rgo">Apply</button><a class="btn ghost sm" id="rexp">${icon('download')}Export CSV</a>
   <label class="btn ghost sm" style="flex-direction:row;cursor:pointer">${icon('upload')}Import CSV<input id="rimp" type="file" accept=".csv,text/csv" hidden></label></div>
   <div id="rtab"></div></div>`;
  $('#mf').onsubmit = async e => {
    e.preventDefault(); const f = Object.fromEntries(new FormData(e.target)); Object.keys(f).forEach(k => f[k] === '' && delete f[k]);
    try { await api('/readings', { method: 'POST', body: JSON.stringify(f) }); toast('Reading saved'); e.target.reset(); $('#merr').textContent = ''; load(); } catch (x) { $('#merr').textContent = x.details ? Object.entries(x.details).map(([k, m]) => `${k}: ${m}`).join(' · ') : x.message; }
  };
  const sync = () => { rf = { ...rf, q: $('#rq').value, from: $('#rfrom').value, to: $('#rto').value, source: $('#rsrc').value, status: $('#rst').value }; };
  $('#rgo').onclick = () => { sync(); rf.page = 1; load(); }; $('#rq').onkeydown = e => e.key === 'Enter' && $('#rgo').click();
  $('#rimp').onchange = async e => { const fd = new FormData(); fd.append('file', e.target.files[0]); try { const r = await api('/readings/import', { method: 'POST', body: fd }); toast(`Imported ${r.inserted}, duplicates ${r.duplicates}, rejected ${r.rejected}`, r.rejected > 0); load(); } catch (x) { toast(x.message, true); } e.target.value = ''; };
  async function load() {
    const q = new URLSearchParams(Object.entries(rf).filter(([k, x]) => x !== '')); q.set('per_page', 25);
    $('#rexp').href = '/api/readings/export?' + new URLSearchParams(Object.entries({ from: rf.from, to: rf.to, source: rf.source }).filter(([k, x]) => x));
    let d; try { d = await api('/readings?' + q); } catch (x) { $('#rtab').innerHTML = `<p class="err">${esc(x.message)}</p>`; return; }
    const th = (k, l) => `<th scope="col" aria-sort="${rf.sort === k ? (rf.order === 'asc' ? 'ascending' : 'descending') : 'none'}"><button data-s="${k}">${l}${rf.sort === k ? (rf.order === 'asc' ? ' ▲' : ' ▼') : ''}</button></th>`;
    $('#rtab').innerHTML = d.total ? `<div class="tw"><table><thead><tr>${th('timestamp', 'Date & time')}${th('voltage', 'Voltage (V)')}${th('current', 'Current (A)')}${th('power', 'Power (W)')}${th('energy_kwh', 'Energy (kWh)')}${th('device_id', 'Device')}${th('data_source', 'Source')}${th('status', 'Status')}</tr></thead><tbody>
     ${d.readings.map(r => `<tr><td>${tf(r.timestamp)}</td><td>${n(r.voltage)}</td><td>${n(r.current, 3)}</td><td>${n(r.power, 1)}</td><td>${n(r.energy_kwh, 3)}</td><td>${esc(r.device_id)}</td><td>${srcPill(r.data_source)}</td><td>${pill(...STAT[r.status])}</td></tr>`).join('')}</tbody></table></div>
     <div class="pager"><span class="muted small">${d.total} readings · page ${d.page}/${d.pages}</span><button class="btn ghost sm" id="pp" ${d.page <= 1 ? 'disabled' : ''}>Previous</button><button class="btn ghost sm" id="pn" ${d.page >= d.pages ? 'disabled' : ''}>Next</button></div>` : '<p class="empty">No readings match.</p>';
    $('#rtab').querySelectorAll('[data-s]').forEach(b => b.onclick = () => { rf.order = rf.sort === b.dataset.s && rf.order === 'desc' ? 'asc' : 'desc'; rf.sort = b.dataset.s; load(); });
    $('#pp')?.addEventListener('click', () => { rf.page--; load(); }); $('#pn')?.addEventListener('click', () => { rf.page++; load(); }); lucide.createIcons();
  }
  load();
}

/* ------------------------------------------------ Alerts */
let af = { severity: '', status: '', type: '' };
async function pgAlerts(v) {
  v.innerHTML = `<div class="bar"><label>Severity<select id="asv"><option value="">All</option><option>Low</option><option>Medium</option><option>High</option></select></label>
  <label>Status<select id="ast"><option value="">All</option>${Object.entries(ASTAT).map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></label>
  <label>Type<select id="aty"><option value="">All</option><option value="voltage_anomaly">Voltage anomaly</option><option value="high_power">High power</option><option value="excess_energy">Excess energy</option><option value="connection_failure">Connection failure</option></select></label></div><div id="al"></div>`;
  $('#asv').value = af.severity; $('#ast').value = af.status; $('#aty').value = af.type;
  async function load() {
    af = { severity: $('#asv').value, status: $('#ast').value, type: $('#aty').value };
    const d = await api('/alerts?' + new URLSearchParams(Object.entries(af).filter(([k, x]) => x))); setMode(d.mode);
    $('#al').innerHTML = banner(d.mode) + (d.alerts.length ? d.alerts.map(a => `<div class="card alert ${a.severity}"><div class="top">${pill(a.severity, SEV[a.severity])}<b>${esc(a.label)}</b>${pill(ASTAT[a.status], a.status === 'open' ? 'warn' : 'mute')}<span class="muted small">${tf(a.timestamp)}</span></div>
      <p>${esc(a.description)}</p><p class="small muted">Suggested action: ${esc(a.suggested_action)}</p>
      <div class="top">${a.status === 'open' ? `<button class="btn sm" data-id="${a.id}" data-st="reviewed">${icon('check')}Mark reviewed</button>` : `<button class="btn ghost sm" data-id="${a.id}" data-st="open">Reopen</button>`}
      ${a.alert_type !== 'connection_failure' && a.status !== 'confirmed_waste' ? `<button class="btn ghost sm" data-id="${a.id}" data-st="confirmed_waste">Confirm as waste</button>` : ''}${a.status !== 'resolved' ? `<button class="btn ghost sm" data-id="${a.id}" data-st="resolved">Resolve</button>` : ''}</div></div>`).join('') : '<div class="card empty">No alerts match.</div>');
    $('#al').querySelectorAll('[data-id]').forEach(b => b.onclick = async () => { try { await api('/alerts/' + b.dataset.id, { method: 'PATCH', body: JSON.stringify({ status: b.dataset.st }) }); load(); } catch (x) { toast(x.message, true); } });
    lucide.createIcons();
  }
  ['asv', 'ast', 'aty'].forEach(i => $('#' + i).onchange = load); load();
}

/* ------------------------------------------------ Settings */
const FIELDS = [
  ['Voltage monitoring (firmware-compatible defaults, not safety limits)', [['voltage_baseline', 'Voltage baseline (V; 0 = learn from first N readings)', 'number'], ['baseline_readings', 'Baseline readings (firmware: 30)', 'number'], ['voltage_threshold_pct', 'Deviation threshold % (firmware: 4)', 'number'], ['consecutive_readings', 'Consecutive abnormal readings (firmware: 3)', 'number']]],
  ['Consumption thresholds', [['high_power_w', 'High power limit (W)', 'number'], ['excess_zscore', 'Excess-energy z-score', 'number'], ['excess_min_ratio', 'Min ratio vs typical', 'number']]],
  ['Electricity tariff', [['tariff_per_unit', 'Cost per unit (₹/kWh)', 'number'], ['additional_charges', 'Additional charges (₹)', 'number'], ['saving_assumption_pct', 'Saving assumption for tips (%)', 'number']]],
  ['Device and sensors', [['device_id', 'Device ID', 'text'], ['power_factor', 'Assumed power factor (used only when power is not measured)', 'number'], ['update_interval_s', 'Device update interval (s)', 'number'], ['stale_after_s', 'Mark data stale after (s)', 'number'], ['timezone', 'Timezone (IANA)', 'text']]],
  ['ThingSpeak field mapping (verify against your ESP32 firmware)', [['ts_field_voltage', 'Voltage field', 'text'], ['ts_field_current', 'Current field', 'text'], ['ts_field_power', 'Power field', 'text'], ['ts_field_energy', 'Energy field', 'text'], ['ts_energy_unit', 'Energy unit in ThingSpeak', 'select:kWh,Wh']]],
  ['Prediction', [['min_train_hours', 'Min hours to train ML model', 'number'], ['test_fraction', 'Test fraction (chronological)', 'number']]],
  ['Notifications', [['telegram_notifications', 'Send Telegram alerts (needs bot configured on the server)', 'checkbox']]]];
async function pgSettings(v) {
  const s = await api('/settings'), V = s.values, I = s.integration, [tT, tC] = tsInfo(I.status); setMode(s.mode);
  const yn = b => pill(b ? 'Configured' : 'Not set', b ? 'ok' : 'mute');
  v.innerHTML = `<div class="grid g2"><div class="card"><h2>Integration status</h2><dl class="kv">
   <dt>ThingSpeak connection</dt><dd>${pill(tT, tC)}</dd><dt>Channel configured</dt><dd>${yn(I.channel_id_set)}</dd><dt>Read API key</dt><dd>${yn(I.read_key_set)}</dd><dt>Write API key</dt><dd>${yn(I.write_key_set)}</dd>
   <dt>Last successful retrieval</dt><dd>${tf(I.status.last_success)}</dd><dt>Newest reading received</dt><dd>${tf(I.status.last_data)}</dd><dt>Device ID</dt><dd>${esc(V.device_id)}</dd>
   <dt>Direct device API key</dt><dd>${yn(I.device_api_key_set)}</dd><dt>Telegram bot</dt><dd>${yn(I.telegram_configured)}</dd><dt>Auto-sync</dt><dd>${I.auto_sync_seconds ? `every ${I.auto_sync_seconds}s` : 'off (manual)'}</dd></dl>
   <p class="hint">${esc(I.status.message)} Secrets are read from the server's environment and are never shown here.</p>
   <div class="bar" style="margin-top:10px">${I.thingspeak_configured ? `<button class="btn" id="tsync">${icon('refresh-cw')}Sync now</button>` : ''}</div></div>
   <div class="card"><h2>Sample data</h2><p class="muted">${s.sample_rows} simulated readings are stored (labelled “Simulated sample”). Resetting regenerates ~30 days ending now and re-runs alert detection. Your own readings are not touched.</p><button class="btn ghost" id="reset">${icon('rotate-ccw')}Reset demo data</button>
   <h3 style="margin-top:16px">Calibration note</h3><p class="muted small">Readings are raw sensor measurements. The voltage sensor and ACS712 must be calibrated against a trusted meter; power derived as V × I × PF is an estimate for AC loads.</p></div></div>
  <form id="sf">${FIELDS.map(([t, fs]) => `<div class="card" style="margin-bottom:14px"><h2>${t}</h2><div class="form">${fs.map(([k, l, ty]) => ty === 'checkbox' ? `<label>${l}<input type="checkbox" name="${k}" ${V[k] ? 'checked' : ''}></label>` : ty.startsWith('select') ? `<label>${l}<select name="${k}">${ty.slice(7).split(',').map(o => `<option ${V[k] === o ? 'selected' : ''}>${o}</option>`).join('')}</select></label>` : `<label>${l}<input name="${k}" type="${ty}" step="any" value="${esc(V[k])}"><span class="err" data-e="${k}"></span></label>`).join('')}</div></div>`).join('')}
   <button class="btn" type="submit">${icon('save')}Save settings</button> <span class="hint">Saving re-runs alert detection on open alerts.</span></form>`;
  $('#sf').onsubmit = async e => {
    e.preventDefault(); document.querySelectorAll('[data-e]').forEach(x => x.textContent = ''); const body = {};
    FIELDS.flatMap(f => f[1]).forEach(([k, , ty]) => { const el = e.target.elements[k]; body[k] = ty === 'checkbox' ? el.checked : ty === 'number' ? (el.value === '' ? '' : Number(el.value)) : el.value; });
    try { await api('/settings', { method: 'PUT', body: JSON.stringify(body) }); toast('Settings saved'); } catch (x) { if (x.details) Object.entries(x.details).forEach(([k, m]) => { const el = document.querySelector(`[data-e="${k}"]`); if (el) el.textContent = m; }); toast(x.message, true); }
  };
  $('#reset').onclick = async () => { if (!confirm('Regenerate the sample data?')) return; try { await api('/sample/reset', { method: 'POST' }); toast('Sample data reset'); navigate(); } catch (x) { toast(x.message, true); } };
  $('#tsync')?.addEventListener('click', async () => { try { const r = await api('/thingspeak/sync', { method: 'POST' }); toast(`Synced: ${r.inserted} new`); } catch (x) { toast(x.message, true); } navigate(); });
}

/* ------------------------------------------------ Router */
const PAGES = { dashboard: ['Dashboard', pgDashboard], prediction: ['AI Prediction', pgPrediction], waste: ['Electricity Waste Detection', pgWaste], bill: ['Electricity Bill Calculator', pgBill], recommendations: ['Energy-Saving Recommendations', pgRecs], readings: ['Sensor Readings', pgReadings], alerts: ['Alerts & Notifications', pgAlerts], settings: ['Device & Settings', pgSettings] };
async function navigate(quiet) {
  const key = (location.hash.slice(1) in PAGES) ? location.hash.slice(1) : 'dashboard', [title, fn] = PAGES[key], v = $('#view');
  clearInterval(timer); Object.values(charts).forEach(c => c.destroy()); charts = {};
  document.querySelectorAll('nav a').forEach(a => a.dataset.page === key ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'));
  $('#title').textContent = title; document.title = title + ' · AI Electricity Waste Predictor'; closeMenu();
  try { await fn(v); } catch (e) { v.innerHTML = `<div class="card empty"><h2>Something went wrong</h2><p>${esc(e.message)}</p><button class="btn" onclick="navigate()">Try again</button></div>`; }
  lucide.createIcons();
  if (key === 'dashboard') timer = setInterval(async () => { if (TSCONF) { try { await api('/thingspeak/sync', { method: 'POST' }); } catch { } } navigate(true); }, 20000);
}
function closeMenu() { $('#sidebar').classList.remove('open'); $('#scrim').hidden = true; $('#menu').setAttribute('aria-expanded', 'false'); }
$('#menu').onclick = () => { $('#sidebar').classList.add('open'); $('#scrim').hidden = false; $('#menu').setAttribute('aria-expanded', 'true'); };
$('#scrim').onclick = closeMenu;
window.addEventListener('hashchange', () => navigate());
navigate();
